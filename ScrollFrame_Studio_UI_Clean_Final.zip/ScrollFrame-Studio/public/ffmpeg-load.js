/**
 * ScrollFrame Studio — FFmpeg core fallback loader.
 *
 * The app bundles @ffmpeg/core into its own build (works when served from any
 * static host with COOP/COEP headers, including GitHub Pages / Netlify /
 * Vercel / Cloudflare Pages). If the bundled core cannot be fetched — e.g.
 * `vite preview` without the cross-origin headers — we transparently fall back
 * to a pinned, immutable copy on the unpkg CDN. Video data itself never leaves
 * the browser: only the ffmpeg.wasm *code* is fetched.
 */
(function () {
  var KEY = "sfms-ffmpeg-core-url";
  var CORE_VERSION = "0.12.10";
  var CDN_URL =
    "https://unpkg.com/@ffmpeg/core@" + CORE_VERSION + "/dist/esm/ffmpeg-core.js";

  function current() {
    try {
      return window.location.origin + "/ffmpeg-core.js";
    } catch (e) {
      return CDN_URL;
    }
  }

  function probe(url, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    xhr.onload = function () {
      cb(xhr.status >= 200 && xhr.status < 400);
    };
    xhr.onerror = function () {
      cb(false);
    };
    xhr.send();
  }

  function pick() {
    var cached = null;
    try {
      cached = localStorage.getItem(KEY);
    } catch (e) {}
    var local = current();
    if (cached === local || cached === CDN_URL) {
      return Promise.resolve(cached);
    }
    return new Promise(function (resolve) {
      probe(local, function (ok) {
        var chosen = ok ? local : CDN_URL;
        try {
          localStorage.setItem(KEY, chosen);
        } catch (e) {}
        resolve(chosen);
      });
    });
  }

  window.__FFMPEG_CORE_LOADER__ = {
    resolve: function () {
      return pick();
    },
    cdnUrl: CDN_URL,
  };
})();
