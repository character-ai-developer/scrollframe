import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

const headers: Record<string, string> = {
  // Required so the FFmpeg WASM worker can be instantiated from blob URLs
  // when the app is served over HTTPS (GitHub Pages, Cloudflare Pages, ...).
  "Cross-Origin-Embedder-Policy": "require-corp",
  "Cross-Origin-Opener-Policy": "same-origin",
};

export default defineConfig({
  plugins: [react(), tailwindcss()],
  worker: {
    format: "es",
  },
  // Ship the ffmpeg.wasm core as static assets so the app works fully
  // self-hosted (no CDN dependency). /ffmpeg-load.js probes these files and
  // falls back to a pinned CDN copy only when they are unreachable.
  assetsInclude: ["**/ffmpeg-core.js", "**/ffmpeg-core.wasm"],
  optimizeDeps: {
    exclude: ["@ffmpeg/ffmpeg", "@ffmpeg/util"],
    include: [],
  },
  build: {
    target: "es2020",
    chunkSizeWarningLimit: 4000,
    rollupOptions: {
      output: {
        manualChunks: {
          ffmpeg: ["@ffmpeg/ffmpeg", "@ffmpeg/util"],
        },
      },
    },
  },
  server: {
    headers,
    // allow the sandbox preview proxy host (and any local hosts)
    allowedHosts: [".e2b.app", "localhost", "127.0.0.1"],
  },
  preview: {
    headers,
  },
});
