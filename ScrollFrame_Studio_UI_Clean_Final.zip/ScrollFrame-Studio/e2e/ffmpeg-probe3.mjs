import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv[2] || "http://localhost:5173";

const browser = await chromium.launch();
const ctx = await browser.newContext();
const page = await ctx.newPage();
page.on("pageerror", (e) => console.log("PAGEERROR:", e.message));
page.on("console", (m) => {
  if (["error", "warning", "info"].includes(m.type())) console.log(`CONSOLE[${m.type()}]:`, m.text().slice(0, 250));
});
await page.goto(BASE, { waitUntil: "domcontentloaded" });

const videoB64 = readFileSync(join(__dirname, "fixtures", "sample.mp4")).toString("base64");

const result = await page.evaluate(async ({ videoB64 }) => {
  const buf = Uint8Array.from(atob(videoB64), (c) => c.charCodeAt(0));
  const file = new File([buf], "sample.mp4", { type: "video/mp4" });
  const { processVideo } = await import("/src/lib/processor.ts");
  const { loadFFmpeg } = await import("/src/lib/ffmpegPool.ts");

  const run = async (runNo) => {
    const events = [];
    const t0 = performance.now();
    try {
      const r = await Promise.race([
        processVideo(
          file,
          { preset: "balanced", fps: 24, maxFrames: 720, imageFormat: "webp", imageQuality: 82, maxResolution: 640, mode: "frames" },
          {
            onProgress: (p) => events.push({ pct: Math.round(p.percent), stage: p.stage }),
            onRecommendation: () => {},
            onLog: (l) => events.push({ log: l.slice(0, 100) }),
          },
        ),
        new Promise((_, rej) => setTimeout(() => rej(new Error("HANG > 120s")), 120000)),
      ]);
      return { runNo, ok: true, ms: Math.round(performance.now() - t0), frameCount: r.frameCount, events: events.slice(0, 15) };
    } catch (e) {
      return { runNo, ok: false, ms: Math.round(performance.now() - t0), err: String((e && e.message) || e), events: events.slice(0, 15) };
    }
  };

  const out = [];
  out.push(await run(1));
  out.push(await run(2));
  // manual chunk exec after both
  try {
    const ffmpeg = await loadFFmpeg();
    const manual = await Promise.race([
      ffmpeg.exec(["-hide_banner", "-loglevel", "error", "-ss", "0", "-i", "input.bin", "-an",
        "-vf", "scale=640:360:flags=lanczos,fps=24", "-frames:v", "10", "-c:v", "libwebp", "-q:v", "82",
        "-f", "image2", "man_%05d.webp"], 60000),
      new Promise((_, rej) => setTimeout(() => rej(new Error("manual HANG")), 70000)),
    ]);
    out.push({ runNo: "manual", ok: true, ret: manual });
  } catch (e) {
    out.push({ runNo: "manual", ok: false, err: String((e && e.message) || e) });
  }
  return out;
}, { videoB64 });

console.log(JSON.stringify(result, null, 2));
await browser.close();
