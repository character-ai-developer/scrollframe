import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv[2] || "http://localhost:5173";

const browser = await chromium.launch();
const ctx = await browser.newContext();
const page = await ctx.newPage();
page.on("pageerror", (e) => console.log("PAGEERROR:", e.message));
page.on("console", (m) => {
  if (["error", "warning"].includes(m.type())) console.log(`CONSOLE[${m.type()}]:`, m.text().slice(0, 300));
});
await page.goto(BASE, { waitUntil: "domcontentloaded" });

const videoB64 = readFileSync(join(__dirname, "fixtures", "sample.mp4")).toString("base64");

const results = await page.evaluate(async ({ videoB64 }) => {
  const { loadFFmpeg } = await import("/src/lib/ffmpegPool.ts");
  const ffmpeg = await loadFFmpeg();
  const logs = [];
  ffmpeg.on("log", ({ type, message }) => {
    if (type === "stderr") logs.push(message);
  });

  async function run(name, args, timeout = 60000) {
    const t0 = performance.now();
    try {
      const ret = await Promise.race([
        ffmpeg.exec(args, timeout),
        new Promise((_, rej) => setTimeout(() => rej(new Error("HANG > timeout")), timeout + 5000)),
      ]);
      return { name, ok: true, ms: Math.round(performance.now() - t0), ret, stderr: logs.splice(0).slice(-6) };
    } catch (e) {
      return {
        name,
        ok: false,
        ms: Math.round(performance.now() - t0),
        err: String((e && e.message) || e),
        stderr: logs.splice(0).slice(-10),
      };
    }
  }

  const out = [];
  out.push(await run("A: testsrc2 -> 10 PNG frames", ["-y", "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=24:duration=1", "-frames:v", "10", "a_%03d.png"]));
  out.push(await run("B: testsrc2 -> 10 WebP frames", ["-y", "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=24:duration=1", "-frames:v", "10", "-c:v", "libwebp", "-q:v", "80", "b_%03d.webp"]));
  out.push(await run("C: testsrc2 -> webp + scale,fps", ["-y", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=1", "-vf", "scale=320:180:flags=lanczos,fps=24", "-frames:v", "24", "-c:v", "libwebp", "-q:v", "80", "c_%03d.webp"]));
  const buf = Uint8Array.from(atob(videoB64), (c) => c.charCodeAt(0));
  await ffmpeg.writeFile("input.bin", buf);
  out.push(await run("D: real mp4 -> webp frames (full repro)", ["-hide_banner", "-loglevel", "error", "-ss", "0", "-i", "input.bin", "-an", "-vf", "scale=640:360:flags=lanczos,fps=24", "-frames:v", "30", "-c:v", "libwebp", "-q:v", "82", "-compression_level", "5", "d_%03d.webp"], 90000));
  return out;
}, { videoB64 });

for (const r of results) {
  console.log(`${r.ok ? "✅" : "❌"} ${r.name} — ${r.ok ? `${r.ms}ms ret=${r.ret}` : `FAILED after ${r.ms}ms: ${r.err}`}`);
  (r.stderr || []).forEach((l) => console.log("     stderr:", l.slice(0, 160)));
}

await browser.close();
