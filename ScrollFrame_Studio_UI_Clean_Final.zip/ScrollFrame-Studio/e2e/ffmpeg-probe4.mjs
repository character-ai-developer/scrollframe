import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv[2] || "http://localhost:5173";

const browser = await chromium.launch();
const ctx = await browser.newContext();
const page = await ctx.newPage();
page.on("pageerror", (e) => console.log("PAGEERROR:", e.message));
page.on("console", (m) => {
  if (["error", "warning", "info"].includes(m.type())) console.log(`CONSOLE[${m.type()}]:`, m.text().slice(0, 200));
});
await page.goto(BASE, { waitUntil: "domcontentloaded" });

const videoB64 = readFileSync(join(__dirname, "fixtures", "sample.mp4")).toString("base64");

const result = await page.evaluate(async ({ videoB64 }) => {
  const { loadFFmpeg } = await import("/src/lib/ffmpegPool.ts");
  const ffmpeg = await loadFFmpeg();
  const logs = [];
  ffmpeg.on("log", ({ type, message }) => {
    if (type === "stderr") logs.push(message);
  });

  const buf = Uint8Array.from(atob(videoB64), (c) => c.charCodeAt(0));
  await ffmpeg.writeFile("input.bin", buf);
  const stderrDump = () => logs.splice(0).slice(-4).map((l) => l.slice(0, 140));

  const CHUNK_ARGS = ["-hide_banner", "-loglevel", "error", "-ss", "0.000", "-i", "input.bin", "-an",
    "-vf", "scale=640:360:flags=lanczos,fps=24", "-frames:v", "144", "-c:v", "libwebp", "-q:v", "82",
    "-compression_level", "5", "-f", "image2", "frame_%05d.webp"];

  async function tryRun(name, setup, args = CHUNK_ARGS, timeout = 60000) {
    const t0 = performance.now();
    try {
      const cleanup = setup ? setup() : null;
      const ret = await Promise.race([
        ffmpeg.exec(args, timeout),
        new Promise((_, rej) => setTimeout(() => rej(new Error("HANG > timeout")), timeout + 5000)),
      ]);
      if (cleanup) cleanup();
      return { name, ok: true, ms: Math.round(performance.now() - t0), ret, stderr: stderrDump() };
    } catch (e) {
      return { name, ok: false, ms: Math.round(performance.now() - t0), err: String((e && e.message) || e), stderr: stderrDump() };
    }
  }

  const out = [];
  out.push(await tryRun("V1: bare exec (control)"));

  out.push(await tryRun("V2: with progress listener", () => {
    const h = () => {};
    ffmpeg.on("progress", h);
    return () => ffmpeg.off("progress", h);
  }));

  out.push(await tryRun("V3: with setInterval ticker", () => {
    const iv = setInterval(() => {}, 400);
    return () => clearInterval(iv);
  }));

  out.push(await tryRun("V4: with JSZip instance + files", () => {
    // eslint-disable-next-line no-eval
    return null;
  }));

  return out;
}, { videoB64 });

for (const r of result) {
  console.log(`${r.ok ? "✅" : "❌"} ${r.name} — ${r.ok ? `${r.ms}ms` : `FAILED ${r.ms}ms: ${r.err}`}`);
  (r.stderr || []).forEach((l) => console.log("     stderr:", l));
}

await browser.close();
