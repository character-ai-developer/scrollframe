#!/usr/bin/env node
/**
 * Generates a deterministic test video with strongly visible motion:
 *  - hue-shifting gradient background
 *  - a bouncing red square + orbiting blue dot
 *  - a big white "FRAME nnn" counter (readable, so scroll position is
 *    verifiable both visually and via pixel sampling)
 *  - a 440 Hz audio tone
 *
 * Frames are rendered as BMPs in pure Node (no canvas/drawtext dependency),
 * then encoded to H.264 with the ffmpeg-static binary.
 *
 * Usage: node e2e/make-sample-video.mjs <out.mp4> [width] [height] [duration] [fps]
 */
import { execFileSync } from "node:child_process";
import { mkdirSync, rmSync, writeFileSync } from "node:fs";
import ffmpegPath from "ffmpeg-static";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const out = process.argv[2] ?? join(__dirname, "fixtures", "sample.mp4");
const W = +(process.argv[3] ?? 640);
const H = +(process.argv[4] ?? 360);
const DUR = +(process.argv[5] ?? 6);
const FPS = +(process.argv[6] ?? 30);

/* ------------------------- tiny 5x7 bitmap font (digits + FRAME) --------- */
const FONT = {
  F: ["11110", "10000", "10000", "11100", "10000", "10000", "10000"],
  R: ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
  A: ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
  M: ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
  E: ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
  "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
  "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
  "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
  "3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
  "4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
  "5": ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
  "6": ["01110", "10000", "10000", "11110", "10001", "10001", "01110"],
  "7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
  "8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
  "9": ["01110", "10001", "10001", "01111", "00001", "00001", "01110"],
};

function drawText(px, x, y, text, scale, color) {
  let cx = x;
  for (const ch of text) {
    const glyph = FONT[ch];
    if (glyph) {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 5; c++) {
          if (glyph[r][c] === "1") {
            for (let dy = 0; dy < scale; dy++) {
              for (let dx = 0; dx < scale; dx++) {
                px.set(cx + c * scale + dx, y + r * scale + dy, color);
              }
            }
          }
        }
      }
      cx += 6 * scale;
    } else {
      cx += 3 * scale;
    }
  }
}

function hue2rgb(h) {
  const i = Math.floor(h * 6);
  const f = h * 6 - i;
  const q = 1 - f;
  switch (i % 6) {
    case 0: return [1, f, 0];
    case 1: return [q, 1, 0];
    case 2: return [0, 1, f];
    case 3: return [0, q, 1];
    case 4: return [f, 0, 1];
    default: return [1, 0, q];
  }
}

function makeFrame(w, h, t, frameNo, total) {
  // pixel buffer with get/set helpers
  const data = new Uint8Array(w * h * 3);
  const px = {
    set(x, y, [r, g, b]) {
      if (x < 0 || y < 0 || x >= w || y >= h) return;
      const i = (y * w + x) * 3;
      data[i] = r;
      data[i + 1] = g;
      data[i + 2] = b;
    },
  };
  // gradient background whose hue rotates with time
  const hue = (t / total) * 0.9;
  for (let y = 0; y < h; y++) {
    const row = y / h;
    for (let x = 0; x < w; x++) {
      const h2 = (hue + x / w * 0.25 + row * 0.15) % 1;
      const [r, g, b] = hue2rgb(h2);
      px.set(x, y, [Math.round(r * 120 + 30), Math.round(g * 120 + 30), Math.round(b * 120 + 30)]);
    }
  }
  // bouncing red square
  const bx = Math.round(60 + (Math.sin(t * 2.1) * 0.5 + 0.5) * (w - 140));
  const by = Math.round(40 + (Math.sin(t * 1.7 + 1) * 0.5 + 0.5) * (h - 140));
  for (let y = by; y < by + 42; y++) {
    for (let x = bx; x < bx + 42; x++) {
      if (x >= 0 && y >= 0 && x < w && y < h) px.set(x, y, [230, 40, 40]);
    }
  }
  // orbiting blue dot
  const ox = Math.round(w / 2 + Math.cos(t * 3.2) * w * 0.32);
  const oy = Math.round(h / 2 + Math.sin(t * 2.6) * h * 0.3);
  for (let y = oy - 9; y < oy + 9; y++) {
    for (let x = ox - 9; x < ox + 9; x++) {
      const d = Math.hypot(x - ox, y - oy);
      if (d < 9 && x >= 0 && y >= 0 && x < w && y < h) px.set(x, y, [60, 140, 255]);
    }
  }
  // frame counter
  const label = `FRAME ${String(frameNo).padStart(3, "0")}`;
  const scale = w >= 640 ? 2 : 1;
  drawText(px, 14, 14, label, scale, [255, 255, 255]);
  drawText(px, 14, 14 + 7 * scale + 6, `T ${t.toFixed(2)}s`, scale, [255, 230, 80]);
  // progress strip at the bottom
  const stripH = 8;
  const progW = Math.round((frameNo / (total * FPS)) * w);
  for (let y = h - stripH; y < h; y++) {
    for (let x = 0; x < w; x++) {
      px.set(x, y, x < progW ? [70, 220, 120] : [30, 30, 34]);
    }
  }
  return data;
}

function writeBMP(path, w, h, data) {
  const rowSize = w * 3;
  const padded = (rowSize + 3) & ~3;
  const pixelOffset = 54;
  const fileSize = pixelOffset + padded * h;
  const buf = Buffer.alloc(fileSize);
  buf.write("BM", 0);
  buf.writeUInt32LE(fileSize, 2);
  buf.writeUInt32LE(pixelOffset, 10);
  buf.writeUInt32LE(40, 14); // BITMAPINFOHEADER
  buf.writeInt32LE(w, 18);
  buf.writeInt32LE(h, 22);
  buf.writeUInt16LE(1, 26);
  buf.writeUInt16LE(24, 28);
  buf.writeUInt32LE(0, 30); // no compression
  buf.writeUInt32LE(padded * h, 34);
  buf.writeInt32LE(2835, 38);
  buf.writeInt32LE(2835, 42);
  // bottom-up rows
  for (let y = 0; y < h; y++) {
    const srcRow = (h - 1 - y) * rowSize;
    const dst = pixelOffset + y * padded;
    buf.set(data.subarray(srcRow, srcRow + rowSize), dst);
  }
  writeFileSync(path, buf);
}

/* ------------------------------------------------------------------ main */
const tmpDir = join(__dirname, ".frames-tmp");
rmSync(tmpDir, { recursive: true, force: true });
mkdirSync(tmpDir, { recursive: true });

const total = DUR * FPS;
for (let i = 0; i < total; i++) {
  const t = i / FPS;
  const frame = makeFrame(W, H, t, i, total);
  writeBMP(join(tmpDir, `f_${String(i).padStart(5, "0")}.bmp`), W, H, frame);
  if (i % 50 === 0) console.log(`  rendered ${i}/${total} frames`);
}

console.log("encoding with ffmpeg…");
const args = [
  "-y",
  "-framerate", String(FPS),
  "-i", join(tmpDir, "f_%05d.bmp"),
  "-f", "lavfi", "-i", `sine=frequency=440:sample_rate=44100:duration=${DUR}`,
  "-c:v", "libx264",
  "-preset", "veryfast",
  "-crf", "20",
  "-pix_fmt", "yuv420p",
  "-c:a", "aac",
  "-b:a", "96k",
  "-shortest",
  "-movflags", "+faststart",
  out,
];
execFileSync(ffmpegPath, args, { stdio: "inherit" });
rmSync(tmpDir, { recursive: true, force: true });
console.log("wrote", out, `${W}x${H}`, `${DUR}s @ ${FPS}fps`);
