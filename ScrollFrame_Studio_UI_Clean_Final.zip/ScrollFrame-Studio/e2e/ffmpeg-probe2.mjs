import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv[2] || "http://localhost:5173";

const browser = await chromium.launch();
const ctx = await browser.newContext();
const page = await ctx.newPage();
page.on("pageerror", (e) => console.log("PAGEERROR:", e.message));
await page.goto(BASE, { waitUntil: "domcontentloaded" });

const videoB64 = readFileSync(join(__dirname, "fixtures", "sample.mp4")).toString("base64");

const results = await page.evaluate(async ({ videoB64 }) => {
  const { loadFFmpeg } = await import("/src/lib/ffmpegPool.ts");
  const ffmpeg = await loadFFmpeg();
  const logs = [];
  ffmpeg.on("log", ({ type, message }) => {
    if (type === "stderr") logs.push(message);
  });

  async function run(name, args, timeout = 60000, waitMs = 0) {
    const t0 = performance.now();
    try {
      const ret = await Promise.race([
        ffmpeg.exec(args, timeout),
        new Promise((_, rej) => setTimeout(() => rej(new Error("HANG > timeout")), timeout + 5000)),
      ]);
      if (waitMs) await new Promise((r) => setTimeout(r, waitMs));
      return { name, ok: true, ms: Math.round(performance.now() - t0), ret, stderr: logs.splice(0).slice(-3) };
    } catch (e) {
      return {
        name,
        ok: false,
        ms: Math.round(performance.now() - t0),
        err: String((e && e.message) || e),
        stderr: logs.splice(0).slice(-6),
      };
    }
  }

  const buf = Uint8Array.from(atob(videoB64), (c) => c.charCodeAt(0));
  await ffmpeg.writeFile("input.bin", buf);

  const out = [];
  // 1: exact probe exec from processor
  out.push(await run("1: probe exec (-i -map -c copy -f null)", ["-hide_banner", "-i", "input.bin", "-map", "0:v:0", "-c", "copy", "-f", "null", "-"], 30000));
  // 2: exact chunk exec from processor (150 frames)
  out.push(await run("2: chunk exec (150 webp frames)", ["-hide_banner", "-loglevel", "error", "-ss", "0", "-i", "input.bin", "-an", "-vf", "scale=640:360:flags=lanczos,fps=24", "-frames:v", "150", "-c:v", "libwebp", "-q:v", "82", "-compression_level", "5", "-f", "image2", "frame_%05d.webp"], 90000));
  // 3: with progress listener attached (as in processor)
  ffmpeg.on("progress", () => {});
  out.push(await run("3: chunk exec again with progress listener", ["-hide_banner", "-loglevel", "error", "-ss", "0", "-i", "input.bin", "-an", "-vf", "scale=640:360:flags=lanczos,fps=24", "-frames:v", "24", "-c:v", "libwebp", "-q:v", "82", "-compression_level", "5", "-f", "image2", "fr_%05d.webp"], 90000));
  // 4: readFile after exec
  try {
    const d = await ffmpeg.readFile("frame_00000.webp");
    out.push({ name: "4: readFile frame_00000.webp", ok: true, ms: 0, ret: d.length });
  } catch (e) {
    out.push({ name: "4: readFile frame_00000.webp", ok: false, ms: 0, err: String(e.message) });
  }
  return out;
}, { videoB64 });

for (const r of results) {
  console.log(`${r.ok ? "✅" : "❌"} ${r.name} — ${r.ok ? `${r.ms}ms ret=${r.ret}` : `FAILED after ${r.ms}ms: ${r.err}`}`);
  (r.stderr || []).forEach((l) => console.log("     stderr:", l.slice(0, 160)));
}

await browser.close();
