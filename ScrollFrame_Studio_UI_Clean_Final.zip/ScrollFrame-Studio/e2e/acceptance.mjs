#!/usr/bin/env node
/**
 * ScrollFrame Studio — full acceptance test.
 *
 * Drives a real Chromium through the entire workflow:
 *   upload → analyze → extract frames → optimize → preview → scroll forward →
 *   scroll backward → resize (responsive) → settings change → export ZIP →
 *   unzip → serve standalone → verify the exported site works on its own.
 *
 * Usage: node e2e/acceptance.mjs [baseUrl]  (default http://localhost:5173)
 */
import { chromium } from "playwright";
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { createServer } from "node:http";
import { dirname, join, extname } from "node:path";
import { fileURLToPath } from "node:url";
import { platform } from "node:os";
import { spawn } from "node:child_process";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, "..");
const BASE = process.argv[2] || "http://localhost:5173";
const FIXTURES = join(__dirname, "fixtures");
const OUT = join(__dirname, "out");

const PASS = [];
const FAIL = [];
function check(name, ok, extra = "") {
  const line = `${ok ? "✅ PASS" : "❌ FAIL"}  ${name}${extra ? ` — ${extra}` : ""}`;
  console.log(line);
  (ok ? PASS : FAIL).push(name);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function waitFor(fn, { timeout = 60000, every = 400, desc = "condition" } = {}) {
  const t0 = Date.now();
  let lastErr;
  while (Date.now() - t0 < timeout) {
    try {
      const v = await fn();
      if (v) return v;
    } catch (e) {
      lastErr = e;
    }
    await sleep(every);
  }
  throw new Error(`Timed out waiting for: ${desc}${lastErr ? ` (${lastErr.message})` : ""}`);
}

/** Static server for the exported site (zero dependencies). */
function serveStatic(dir, port) {
  const server = createServer((req, res) => {
    let path = decodeURIComponent(new URL(req.url, "http://x").pathname);
    if (path === "/") path = "/index.html";
    const file = join(dir, path);
    if (!file.startsWith(dir) || !existsSync(file)) {
      res.writeHead(404);
      res.end("not found");
      return;
    }
    const ext = extname(file);
    const types = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".webp": "image/webp", ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg", ".mp4": "video/mp4", ".md": "text/plain" };
    res.writeHead(200, { "content-type": types[ext] || "application/octet-stream" });
    res.end(readFileSync(file));
  });
  return new Promise((resolve) => {
    server.listen(port, "127.0.0.1", () => resolve(server));
  });
}

/* ------------------------------------------------------------------ main */
const browser = await chromium.launch();

async function openApp() {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console.error: ${m.text()}`);
  });
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("text=ScrollFrame", { timeout: 15000 });
  return { ctx, page, errors };
}

async function processVideo(page, filePath, { mode = "frames" } = {}) {
  // upload
  await page.click("text=New Project");
  await page.waitForSelector("input[type=file]", { state: "attached" });
  await page.setInputFiles("input[type=file]", filePath);
  // wait for metadata chips
  await waitFor(
    async () => (await page.locator("text=Process video").count()) > 0,
    { timeout: 30000, desc: "metadata read + Process button enabled" },
  );
  if (mode === "video") {
    await page.click("text=Video Mode");
  }
  await page.click("text=Process video");
  // wait for completion (overlay appears with Complete stage)
  await waitFor(
    async () => {
      const overlay = await page.locator("text=Processing complete").count();
      return overlay > 0;
    },
    { timeout: 600000, desc: "processing complete" },
  );
  await sleep(600);
  // dismiss the completion overlay so the workspace is interactive
  const viewBtn = page.locator("button", { hasText: "View project" });
  if ((await viewBtn.count()) > 0) await viewBtn.click();
  await sleep(400);
}

/** Sample a fingerprint of the preview canvas + read runtime state. */
async function previewSnapshot(page) {
  const frame = page.frames().find((f) => f.url().startsWith("blob:"));
  if (!frame) throw new Error("preview iframe not found");
  return await frame.evaluate(() => {
    const canvas = document.getElementById("sfs-canvas");
    if (!canvas) return null;
    const ctx = canvas.getContext("2d");
    const { width, height } = canvas;
    const data = ctx.getImageData(0, 0, width, height).data;
    // sample a sparse grid of pixels
    let hash = 0;
    const step = Math.max(8, Math.floor(width / 24));
    for (let y = 0; y < height; y += step) {
      for (let x = 0; x < width; x += step) {
        const i = (y * width + x) * 4;
        hash = (hash * 31 + data[i] * 3 + data[i + 1] * 5 + data[i + 2] * 7) >>> 0;
      }
    }
    return {
      hash,
      state: window.__sfsState || null,
      scrollY: window.scrollY,
      innerH: window.innerHeight,
      canvasW: width,
      canvasH: height,
    };
  });
}

async function scrollPreviewTo(page, fraction) {
  const frame = page.frames().find((f) => f.url().startsWith("blob:"));
  if (!frame) throw new Error("preview iframe not found");
  await frame.evaluate((frac) => {
    const anim = document.getElementById("sfs-anim");
    const travel = anim.getBoundingClientRect().height - window.innerHeight;
    window.scrollTo(0, travel * frac);
  }, fraction);
  // wait until the runtime's eased+smoothed progress stabilizes
  let last = null;
  let stable = 0;
  await waitFor(
    async () => {
      const s = await frame.evaluate(() => window.__sfsState || null);
      if (!s || !s.realFrame) return false;
      if (last !== null && Math.abs(s.progress - last) < 0.004) {
        stable++;
        if (stable >= 2) return true;
      } else {
        stable = 0;
      }
      last = s.progress;
      return false;
    },
    { timeout: 20000, every: 250, desc: `preview progress stable @ ${fraction}` },
  );
  await sleep(200);
}

/* ================================================================ RUN */

console.log(`\n🎬 ScrollFrame Studio acceptance test — ${BASE}\n`);

// ---- phase 0: app shell -------------------------------------------------
{
  const { ctx, page, errors } = await openApp();
  check("App loads with sidebar (Projects / New Project / Settings)", (await page.locator("aside").count()) === 1);
  check("Dashboard hero visible", (await page.locator("text=Turn any video into").count()) > 0);
  check("Privacy note visible", (await page.locator("text=100% local processing").count()) > 0);

  // ---- phase 1: upload + process ------------------------------------------
  const videoPath = join(FIXTURES, "sample.mp4");
  await processVideo(page, videoPath);
  check("Processing completes and workspace opens", (await page.locator("text=Customize").count()) > 0);
  check("No page errors during processing", errors.length === 0, errors.join(" | ").slice(0, 300));

  // ---- phase 2: live preview + scroll scrubbing ----------------------------
  const iframe = page.frames().find((f) => f.url().startsWith("blob:"));
  check("Live preview iframe present", !!iframe);
  if (iframe) {
    // wait until the runtime has painted a real frame
    await waitFor(
      async () => {
        const s = await previewSnapshot(page);
        return s && s.state && s.state.ready && s.state.realFrame;
      },
      { timeout: 30000, desc: "preview runtime ready (real frame)" },
    );

    const f0 = await previewSnapshot(page);
    await scrollPreviewTo(page, 0.25);
    const f25 = await previewSnapshot(page);
    await scrollPreviewTo(page, 0.5);
    const f50 = await previewSnapshot(page);
    await scrollPreviewTo(page, 0.75);
    const f75 = await previewSnapshot(page);
    await scrollPreviewTo(page, 1);
    const f100 = await previewSnapshot(page);

    check("Frames advance when scrolling down (0%→100% all differ)",
      [f0, f25, f50, f75, f100].every((s) => !!s) &&
        new Set([f0.hash, f25.hash, f50.hash, f75.hash, f100.hash]).size === 5);
    check("Frame index tracks scroll progress (0%→0, 50%→~half, 100%→last)",
      f0.state.frameIndex <= 2 &&
        f50.state.frameIndex > f0.state.frameIndex &&
        Math.abs(f50.state.frameIndex - f50.state.framesTotal * 0.5) <= 10 &&
        f100.state.progress > 0.99 && f100.state.frameIndex >= f100.state.framesTotal - 2,
      `frames=${f0.state.framesTotal} at 0/50/100%: ${f0.state.frameIndex}/${f50.state.frameIndex}/${f100.state.frameIndex} (p=${f0.state.progress.toFixed(2)}/${f50.state.progress.toFixed(2)}/${f100.state.progress.toFixed(2)})`);

    // reverse
    await scrollPreviewTo(page, 0.3);
    const back30 = await previewSnapshot(page);
    await scrollPreviewTo(page, 0.05);
    const back05 = await previewSnapshot(page);
    check("Scrolling up reverses the animation (frame index decreases)",
      back30.state.frameIndex > back05.state.frameIndex,
      `${back30.state.frameIndex} → ${back05.state.frameIndex}`);
    const totalFrames = back05.state.framesTotal || 144;
    const expectedNearTop = Math.round(0.05 * (totalFrames - 1)); // linear mapping
    check("Scrolling back to ~0% returns to the first frames",
      back05.state.frameIndex <= expectedNearTop + 2 && back05.state.frameIndex < back30.state.frameIndex,
      `frameIndex=${back05.state.frameIndex} (linear expects ≈${expectedNearTop})`);

    // fast-scrub: jump from ~0 to 85% in one step — the frame index must never
    // collapse back toward the first frames (poster flash regression)
    const frame2 = page.frames().find((f) => f.url().startsWith("blob:"));
    await frame2.evaluate(() => {
      const anim = document.getElementById("sfs-anim");
      const travel = anim.getBoundingClientRect().height - window.innerHeight;
      window.scrollTo(0, travel * 0.85);
    });
    const samples = [];
    for (let k = 0; k < 24; k++) {
      await sleep(80);
      const s = await frame2.evaluate(() => window.__sfsState || null);
      if (s) samples.push({ fi: s.frameIndex, real: s.realFrame, p: s.progress, ft: s.framesTotal });
    }
    const maxFi = Math.max(...samples.map((x) => x.fi));
    const final = samples[samples.length - 1];
    // default easing is now linear: 85% scroll → ~85% of the frames
    const expected = Math.round(0.85 * (final.ft - 1));
    // after the first samples, the frame index must only move forward while
    // catching up — never collapse back toward frame 0/1 (poster flash)
    const tail = samples.slice(5);
    const collapsed = tail.some((x, i) => i > 0 && x.fi < tail[i - 1].fi - 2);
    check("Fast scrub never flashes back to the start (no poster flash)",
      !collapsed && maxFi >= 120 && final.fi >= expected - 12,
      `max=${maxFi} final=${final.fi} expected≈${expected}${collapsed ? " (collapsed!)" : ""}`);
    await scrollPreviewTo(page, 0);
  }

  // ---- phase 3: responsive / mobile -----------------------------------------
  await page.setViewportSize({ width: 390, height: 844 });
  await sleep(800);
  {
    const m = await previewSnapshot(page);
    check("Preview works at mobile viewport (390×844)", !!m && m.canvasW > 0 && m.canvasH > 0);
    if (m) {
      await scrollPreviewTo(page, 0.5);
      const m50 = await previewSnapshot(page);
      await scrollPreviewTo(page, 0);
      const m0 = await previewSnapshot(page);
      check("Mobile scroll scrubbing works (frames move)",
        m50.state.frameIndex > m0.state.frameIndex,
        `${m0.state.frameIndex} → ${m50.state.frameIndex}`);
    }
  }
  await page.setViewportSize({ width: 1440, height: 900 });
  await sleep(500);

  // ---- phase 4: settings change regenerates preview -------------------------
  await page.click("text=Accent color");
  await page.fill("input[type=color]:right-of(:text('Accent color'))", "#22d3ee");
  await sleep(1200); // debounce + rebuild
  {
    const after = await previewSnapshot(page);
    check("Changing accent color regenerates the preview", !!after && after.state !== null);
  }

  // ---- phase 5: export ZIP --------------------------------------------------
  const [download] = await Promise.all([
    page.waitForEvent("download", { timeout: 300000 }),
    page.click("text=Export Website"),
  ]);
  check("ZIP downloads", !!download, download.suggestedFilename());
  const zipPath = join(OUT, "export.zip");
  rmSync(OUT, { recursive: true, force: true });
  mkdirSync(OUT, { recursive: true });
  await download.saveAs(zipPath);
  check("ZIP file exists and is non-trivial", statSync(zipPath).size > 10000, `${Math.round(statSync(zipPath).size / 1024)} KB`);

  // unzip (use ffmpeg-free unzip: node has no builtin; use system unzip if present, else python3)
  const siteDir = join(OUT, "site");
  rmSync(siteDir, { recursive: true, force: true });
  mkdirSync(siteDir, { recursive: true });
  try {
    execFileSync("unzip", ["-o", zipPath, "-d", siteDir], { stdio: "pipe" });
  } catch {
    execFileSync("python3", ["-c", "import zipfile,sys;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])", zipPath, siteDir]);
  }
  const files = readdirSync(siteDir, { recursive: true }).map((f) => f.replaceAll("\\", "/")).sort();
  const has = (p) => files.includes(p);
  check("ZIP contains index.html / style.css / script.js / README.md",
    has("index.html") && has("style.css") && has("script.js") && has("README.md"));
  const frameFiles = files.filter((f) => f.startsWith("assets/frames/frame_") && f.endsWith(".webp"));
  check(`ZIP contains ${frameFiles.length} individual frames`, frameFiles.length >= 100, `${frameFiles.length} frames`);
  check("ZIP frame names are deterministic (frame_00001…N)",
    has("assets/frames/frame_00001.webp") &&
      has(`assets/frames/frame_${String(frameFiles.length).padStart(5, "0")}.webp`));
  check("ZIP contains poster", files.some((f) => f.startsWith("assets/poster.")));
  check("No absolute/localhost references in generated files (fully portable)",
    !["index.html", "script.js", "style.css", "README.md"]
      .map((f) => readFileSync(join(siteDir, f), "utf8"))
      .join("\n")
      .includes("localhost"));
  check("No API keys / external service calls in the generated site",
    !readFileSync(join(siteDir, "script.js"), "utf8").includes("apiKey") &&
      !readFileSync(join(siteDir, "index.html"), "utf8").includes("apiKey"));

  // ---- phase 6: standalone site works independently --------------------------
  const server = await serveStatic(siteDir, 4174);
  try {
    const ctx2 = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page2 = await ctx2.newPage();
    const errs2 = [];
    page2.on("pageerror", (e) => errs2.push(e.message));
    await page2.goto("http://127.0.0.1:4174/", { waitUntil: "domcontentloaded" });
    check("Exported site loads standalone (no app origin)", (await page2.locator("canvas#sfs-canvas").count()) === 1);
    await waitFor(
      async () => {
        const s = await page2.evaluate(() => window.__sfsState || null);
        return s && s.ready;
      },
      { timeout: 30000, desc: "standalone site runtime ready" },
    );

    const snap = async () =>
      page2.evaluate(() => {
        const canvas = document.getElementById("sfs-canvas");
        const ctx = canvas.getContext("2d");
        const d = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
        let h = 0;
        for (let i = 0; i < d.length; i += 4096) h = (h * 31 + d[i]) >>> 0;
        return { h, s: window.__sfsState, scrollY: window.scrollY };
      });
    const scrollTo = async (frac) => {
      await page2.evaluate((f) => {
        const anim = document.getElementById("sfs-anim");
        const travel = anim.getBoundingClientRect().height - window.innerHeight;
        window.scrollTo(0, travel * f);
      }, frac);
      await waitFor(
        async () => {
          const st = await page2.evaluate(() => window.__sfsState || null);
          if (!st || !st.realFrame) return false;
          return Math.abs(st.frameIndex - Math.round(frac * (st.framesTotal - 1))) <= 6;
        },
        { timeout: 20000, every: 250, desc: `standalone frame near ${frac}` },
      );
      await sleep(300);
    };

    const a0 = await snap();
    await scrollTo(0.5);
    const a50 = await snap();
    await scrollTo(1);
    const a100 = await snap();
    await scrollTo(0.5);
    const b50 = await snap();
    await scrollTo(0);
    const b0 = await snap();

    check("Standalone: scroll forward changes frames",
      a0.s.frameIndex < a50.s.frameIndex && a50.s.frameIndex < a100.s.frameIndex,
      `${a0.s.frameIndex} → ${a50.s.frameIndex} → ${a100.s.frameIndex}`);
    check("Standalone: scroll backward reverses (deterministic)",
      b50.s.frameIndex === a50.s.frameIndex && b0.s.frameIndex === a0.s.frameIndex,
      `50%: ${a50.s.frameIndex}/${b50.s.frameIndex}  0%: ${a0.s.frameIndex}/${b0.s.frameIndex}`);
    check("Standalone: canvas pixels differ across scroll positions",
      a0.h !== a50.h && a50.h !== a100.h);
    check("Standalone: no page errors", errs2.length === 0, errs2.join(" | ").slice(0, 300));
    check("Standalone: total frames match export count",
      a0.s.framesTotal === frameFiles.length, `${a0.s.framesTotal} === ${frameFiles.length}`);
    await ctx2.close();
  } finally {
    server.close();
  }

  // ---- phase 7: video mode with vertical video -------------------------------
  await page.setViewportSize({ width: 1440, height: 900 });
  await processVideo(page, join(FIXTURES, "sample-vertical.mp4"), { mode: "video" });
  check("Video-mode processing completes (vertical 9:16)", (await page.locator("text=Customize").count()) > 0);
  {
    const v = await previewSnapshot(page);
    check("Video-mode preview works (9:16 canvas, no stretching)", !!v && v.canvasW > 0);
  }
  const [dl2] = await Promise.all([
    page.waitForEvent("download", { timeout: 300000 }),
    page.click("text=Export Website"),
  ]);
  const zip2Path = join(OUT, "export-video.zip");
  await dl2.saveAs(zip2Path);
  const siteDir2 = join(OUT, "site-video");
  rmSync(siteDir2, { recursive: true, force: true });
  mkdirSync(siteDir2, { recursive: true });
  try {
    execFileSync("unzip", ["-o", zip2Path, "-d", siteDir2], { stdio: "pipe" });
  } catch {
    execFileSync("python3", ["-c", "import zipfile,sys;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])", zip2Path, siteDir2]);
  }
  const files2 = readdirSync(siteDir2, { recursive: true }).map((f) => f.replaceAll("\\", "/")).sort();
  check("Video-mode ZIP contains assets/video.mp4 + poster",
    files2.includes("assets/video.mp4") && files2.some((f) => f.startsWith("assets/poster.")),
    files2.join(", ").slice(0, 200));

  check("No page errors through the whole session", errors.length === 0, errors.join(" | ").slice(0, 300));
  await ctx.close();
}

await browser.close();

/* ------------------------------------------------------------- summary */
console.log(`\n${"═".repeat(60)}`);
console.log(`  Results: ${PASS.length} passed, ${FAIL.length} failed`);
if (FAIL.length) {
  console.log("\n  Failed checks:");
  FAIL.forEach((f) => console.log(`   ✗ ${f}`));
  process.exit(1);
} else {
  console.log("  🎉 All acceptance checks passed.");
}
