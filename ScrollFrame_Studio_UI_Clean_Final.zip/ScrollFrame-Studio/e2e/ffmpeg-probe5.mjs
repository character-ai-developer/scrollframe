import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv[2] || "http://localhost:5173";

const browser = await chromium.launch();
const ctx = await browser.newContext();
const page = await ctx.newPage();
page.on("pageerror", (e) => console.log("PAGEERROR:", e.message));
page.on("console", (m) => {
  if (["error", "warning", "info"].includes(m.type())) console.log(`CONSOLE[${m.type()}]:`, m.text().slice(0, 250));
});
await page.goto(BASE, { waitUntil: "domcontentloaded" });

const videoB64 = readFileSync(join(__dirname, "fixtures", "sample.mp4")).toString("base64");

const result = await page.evaluate(async ({ videoB64 }) => {
  const out = [];
  const buf = Uint8Array.from(atob(videoB64), (c) => c.charCodeAt(0));

  async function attempt(name, fn) {
    const t0 = performance.now();
    try {
      const r = await Promise.race([
        fn(),
        new Promise((_, rej) => setTimeout(() => rej(new Error("HANG > 60s")), 60000)),
      ]);
      out.push({ name, ok: true, ms: Math.round(performance.now() - t0), r });
    } catch (e) {
      out.push({ name, ok: false, ms: Math.round(performance.now() - t0), err: String((e && e.message) || e) });
    }
  }

  // Case 1: import processor module FIRST (as processVideo would), then manual steps
  await import("/src/lib/processor.ts");
  {
    const { loadFFmpeg } = await import("/src/lib/ffmpegPool.ts");
    const ffmpeg = await loadFFmpeg();
    const collected = [];
    ffmpeg.on("log", ({ message }) => { collected.push(message); if (collected.length > 60) collected.shift(); });
    // replicate probeVideoMeta like the processor does
    try {
      const { probeVideoMeta } = await import("/src/utils/video.ts");
      const f = new File([buf], "sample.mp4", { type: "video/mp4" });
      const meta = await probeVideoMeta(f);
      console.info("probeVideoMeta ok:", meta.duration, meta.width + "x" + meta.height);
    } catch (e) {
      console.info("probeVideoMeta failed:", String((e && e.message) || e));
    }
    // replicate JSZip construction like the processor does
    try {
      const JSZip = (await import("/@id/jszip")).default;
      const zip = new JSZip();
      zip.folder("assets/frames");
      console.info("jszip ok");
    } catch (e) {
      console.info("jszip import failed:", String(e.message || e));
    }
    await ffmpeg.writeFile("input.bin", buf);
    // replicate the processor's surroundings: progress listener + ticker
    let lastP = 0;
    const onP = ({ progress }) => { lastP = progress; };
    ffmpeg.on("progress", onP);
    const ticker = setInterval(() => { void lastP; }, 400);
    await attempt("1: probe exec (after importing processor.ts)", () =>
      ffmpeg.exec(["-hide_banner", "-i", "input.bin", "-map", "0:v:0", "-c", "copy", "-f", "null", "-"], 30000),
    );
    await attempt("2a: chunk exec timeout=60000", () =>
      ffmpeg.exec(["-hide_banner", "-loglevel", "error", "-ss", "0.000", "-i", "input.bin", "-an",
        "-vf", "scale=640:360:flags=lanczos,fps=24", "-frames:v", "144", "-c:v", "libwebp", "-q:v", "82",
        "-compression_level", "5", "-f", "image2", "f2a_%05d.webp"], 60000),
    );
    await attempt("2b: chunk exec timeout=300000", () =>
      ffmpeg.exec(["-hide_banner", "-loglevel", "error", "-ss", "0.000", "-i", "input.bin", "-an",
        "-vf", "scale=640:360:flags=lanczos,fps=24", "-frames:v", "144", "-c:v", "libwebp", "-q:v", "82",
        "-compression_level", "5", "-f", "image2", "f2b_%05d.webp"], 300000),
    );
    clearInterval(ticker);
    ffmpeg.off("progress", onP);
    // TILE TEST: tile filter output + readFile + listDir
    try {
      const tArgs = ["-hide_banner", "-i", "input.bin", "-an",
        "-vf", "scale=320:180:flags=lanczos,fps=6,tile=5x2",
        "-frames:v", "4", "-c:v", "libwebp", "-q:v", "82", "-compression_level", "5", "-y", "sheet_%03d.webp"];
      const ret = await ffmpeg.exec(tArgs, 120000);
      console.info("TILE exec ret:", ret, "| stderr:", collected.slice(-10).join(" | ").slice(0, 400));
      const names = await ffmpeg.listDir("/");
      const sheets = names.filter((n) => n.name.startsWith("sheet"));
      console.info("TILE sheets found:", sheets.length, sheets.map((s) => s.name).join(","));
      if (sheets.length) {
        const d = await ffmpeg.readFile(sheets[0].name);
        console.info("TILE readFile first-sheet ok:", d.length);
      }
      // image2 naming check
      await ffmpeg.exec(["-hide_banner", "-loglevel", "error", "-ss", "0", "-i", "input.bin", "-an",
        "-vf", "scale=320:180:flags=lanczos,fps=6", "-frames:v", "3", "-c:v", "libwebp", "-q:v", "82",
        "-f", "image2", "img_%05d.webp"], 60000);
      const names2 = await ffmpeg.listDir("/");
      const imgs = names2.filter((n) => n.name.startsWith("img_")).map((n) => n.name);
      console.info("IMAGE2 names:", imgs.join(","));
      // with explicit -start_number 0
      await ffmpeg.exec(["-hide_banner", "-loglevel", "error", "-ss", "0", "-i", "input.bin", "-an",
        "-vf", "scale=320:180:flags=lanczos,fps=6", "-frames:v", "3", "-c:v", "libwebp", "-q:v", "82",
        "-start_number", "0", "-f", "image2", "img0_%05d.webp"], 60000);
      const names3 = await ffmpeg.listDir("/");
      const imgs0 = names3.filter((n) => n.name.startsWith("img0_")).map((n) => n.name);
      console.info("IMAGE2(start 0) names:", imgs0.join(","));
    } catch (e) {
      console.info("TILE FAILED:", String((e && e.message) || e), "| stderr:", collected.slice(-10).join(" | ").slice(0, 400));
    }
  }
  return { out };
}, { videoB64 });

for (const r of result.out) {
  console.log(`${r.ok ? "✅" : "❌"} ${r.name} — ${r.ok ? `${r.ms}ms` : `FAILED ${r.ms}ms: ${r.err}`}`);
}

await browser.close();
