#!/usr/bin/env node
/**
 * ScrollFrame Studio — file:// smoke test for the generated website.
 *
 * Proves the exported site works when opened directly from disk:
 *   1. Builds a real project through processVideo + exportProjectAsZip (the
 *      exact pipeline the user's "Export Website" button runs).
 *   2. Unzips it to disk, runs `node --check` on the generated script.js
 *      (spec: the generated runtime must pass syntax validation).
 *   3. Opens index.html via file:// in a real browser context.
 *   4. Verifies: warmup completes (≥12 frames decoded before the loader
 *      hides), the canvas is never blank, scrolling drives frames forward,
 *      reversing drives them backward, the fetch-based path failed and the
 *      <img> fallback engaged (useFetch → false), zero console errors.
 *
 * Usage: node e2e/file-smoke.mjs [baseUrl]
 */
import { chromium } from "playwright";
import JSZip from "jszip";
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, rmSync, statSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv[2] || "http://localhost:5173";
const OUT = join(__dirname, "out", "file-site");

const PASS = [];
const FAIL = [];
function check(name, ok, extra = "") {
  const line = `${ok ? "✅ PASS" : "❌ FAIL"}  ${name}${extra ? ` — ${extra}` : ""}`;
  console.log(line);
  (ok ? PASS : FAIL).push(name);
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
async function waitFor(fn, { timeout = 30000, every = 100, desc = "condition" } = {}) {
  const t0 = Date.now();
  let lastErr;
  while (Date.now() - t0 < timeout) {
    try {
      const v = await fn();
      if (v) return v;
    } catch (e) {
      lastErr = e;
    }
    await sleep(every);
  }
  throw new Error(`Timed out waiting for: ${desc}${lastErr ? ` (${lastErr.message})` : ""}`);
}

/* Build a real export inside the app page (real processVideo + exporter). */
const BUILD_AND_EXPORT = async ({ videoB64 }) => {
  const bin = Uint8Array.from(atob(videoB64), (c) => c.charCodeAt(0));
  const file = new File([bin], "sample.mp4", { type: "video/mp4" });
  const { processVideo } = await import("/src/lib/processor.ts");
  const { exportProjectAsZip } = await import("/src/lib/exporter.ts");
  const { DEFAULT_SITE_SETTINGS, DEFAULT_PROCESSING } = await import("/src/types.ts");

  const result = await processVideo(
    file,
    {
      ...DEFAULT_PROCESSING,
      mode: "frames",
      fps: 12,
      maxFrames: 720,
      maxResolution: 640,
      imageFormat: "webp",
      imageQuality: 82,
    },
    { onProgress: () => {}, onRecommendation: () => {} },
  );

  const project = {
    id: "file-smoke",
    name: "file-smoke",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    videoMeta: result.meta,
    processingSettings: { ...DEFAULT_PROCESSING, mode: "frames", fps: 12, maxFrames: 720, maxResolution: 640, imageFormat: "webp", imageQuality: 82 },
    siteSettings: DEFAULT_SITE_SETTINGS,
    result: {
      count: result.frameCount,
      fps: result.effectiveFps,
      width: result.outputWidth,
      height: result.outputHeight,
      framesBlob: result.framesBlob,
      posterBlob: result.posterBlob,
      totalBytes: result.totalBytes,
      sourceBytes: file.size,
      timeMs: result.timeMs,
      format: result.format,
      mode: result.mode,
      estimatedTotalBytes: result.totalBytes,
      frames: result.frames,
      videoBlob: null,
    },
  };

  const zip = await exportProjectAsZip(project, () => {});
  const buf = new Uint8Array(await zip.arrayBuffer());
  let b64 = "";
  for (let i = 0; i < buf.length; i += 0x8000) {
    b64 += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  }
  return { b64: btoa(b64), frameCount: result.frameCount };
};

const videoB64 = readFileSync(join(__dirname, "fixtures", "sample.mp4")).toString("base64");

const browser = await chromium.launch();
console.log(`\n📁 ScrollFrame Studio file:// smoke test — ${BASE}\n`);

/* --------------------------------------------------------------- 1. export */
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.goto(BASE, { waitUntil: "domcontentloaded" });
const { b64, frameCount } = await page.evaluate(BUILD_AND_EXPORT, { videoB64 });
check("Export pipeline produced a ZIP", b64.length > 1000, `${Math.round((b64.length * 3) / 4 / 1024)} KB base64`);

/* ------------------------------------------------------ 2. unzip to disk */
rmSync(OUT, { recursive: true, force: true });
mkdirSync(OUT, { recursive: true });
const zip = await JSZip.loadAsync(Buffer.from(b64, "base64"));
const names = Object.keys(zip.files).filter((n) => !zip.files[n].dir);
for (const n of names) {
  const p = join(OUT, n);
  mkdirSync(join(OUT, n.split("/").slice(0, -1).join("/")), { recursive: true });
  writeFileSync(p, Buffer.from(await zip.files[n].async("arraybuffer")));
}
const frameFiles = names.filter((n) => n.startsWith("assets/frames/frame_"));
check(`ZIP contains ${frameFiles.length} individual frames`, frameFiles.length === frameCount, `${frameFiles.length}/${frameCount}`);
check("ZIP contains poster + index.html + script.js + README",
  names.includes("assets/poster.webp") && names.includes("index.html") && names.includes("script.js") && names.includes("README.md"));

/* ------------------------------------------------- 3. node --check script.js */
let syntaxOk = true;
let syntaxErr = "";
try {
  execFileSync("node", ["--check", join(OUT, "script.js")], { stdio: "pipe" });
} catch (e) {
  syntaxOk = false;
  syntaxErr = String(e.stderr || e).slice(0, 300);
}
check("Generated script.js passes `node --check`", syntaxOk, syntaxErr);
check("ZIP is non-trivial in size", statSync(join(OUT, "index.html")).size > 1000, `${statSync(join(OUT, "index.html")).size} B index.html`);

/* --------------------------------------------- 4. open via file:// (new context) */
const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const fpage = await ctx.newPage();
const errors = [];
const consoleErrors = [];
fpage.on("pageerror", (e) => errors.push(e.message));
fpage.on("console", (m) => {
  if (m.type() === "error") consoleErrors.push(m.text());
});
const fileUrl = "file://" + join(OUT, "index.html");
await fpage.goto(fileUrl, { waitUntil: "domcontentloaded" });

// warmup completes on file:// (the <img> fallback path)
const ready = await waitFor(
  async () => {
    const s = await fpage.evaluate(() => ({
      sfs: window.__sfsState || null,
      warmup: window.__sfsWarmup || null,
      loadingGone: (() => {
        const el = document.getElementById("sfs-loading");
        return !el || el.classList.contains("sfs-done");
      })(),
      debug: window.__scrollFrameDebug || null,
    }));
    return s && s.sfs && s.sfs.ready && s.sfs.realFrame && s.warmup && s.loadingGone ? s : null;
  },
  { timeout: 30000, desc: "file:// site ready (warmup via <img> fallback)" },
);
check("file:// warmup decoded ≥12 frames before loader hides", ready.warmup.ready >= 12, `ready=${ready.warmup.ready}/${ready.warmup.wanted}`);
check("file:// first real frame drawn without scrolling", ready.sfs.realFrame === true && ready.sfs.frameIndex === 0);
check("file:// fetch path failed → <img> fallback engaged", ready.debug.useFetch === false, `useFetch=${ready.debug.useFetch}`);
check("file:// frameCount is sane", ready.sfs.framesTotal === frameCount, `framesTotal=${ready.sfs.framesTotal}`);

// NOTE: on file://, Chrome taints the canvas (local images drawn without
// CORS) — pixel READBACK via getImageData is blocked, but display is fully
// functional. Verify visually with element screenshots instead.
const canvasShot = async () => Buffer.from(await fpage.locator("#sfs-canvas").screenshot());
const shotFingerprint = (buf) => {
  // PNG byte-length + a cheap structural probe: a flat/blank canvas PNG is a
  // few KB; a real video frame compresses to far more.
  const uniq = new Set();
  for (let i = 0; i < buf.length; i += 997) uniq.add(buf[i]);
  return { bytes: buf.length, uniq: uniq.size };
};
const fp0 = shotFingerprint(await canvasShot());
check("file:// canvas is not blank (has real pixels)", fp0.bytes > 6000, `pngBytes=${fp0.bytes}`);

// scroll drives frames forward
const travel = await fpage.evaluate(() => {
  const anim = document.getElementById("sfs-anim");
  return anim.getBoundingClientRect().height - window.innerHeight;
});
await fpage.evaluate((t) => window.scrollTo(0, t * 0.5), travel);
await waitFor(
  async () => {
    const s = await fpage.evaluate(() => window.__sfsState || null);
    return s && s.frameIndex >= Math.round(0.5 * (frameCount - 1)) - 12;
  },
  { timeout: 10000, every: 50, desc: "file:// 50% scroll" },
);
const mid = await fpage.evaluate(() => window.__sfsState);
const fp50 = shotFingerprint(await canvasShot());
check("file:// scroll drives frames forward (linear 50%)", Math.abs(mid.frameIndex - Math.round(0.5 * (frameCount - 1))) <= 12, `frame=${mid.frameIndex} expected≈${Math.round(0.5 * (frameCount - 1))}`);
check("file:// canvas content changed with the scroll", fp50.bytes !== fp0.bytes, `pngBytes=${fp0.bytes} → ${fp50.bytes}`);

// middle of animation is visible (no blank, no poster reset)
check("file:// middle of animation shows a real frame", mid.realFrame === true && mid.frameIndex > Math.round(0.3 * (frameCount - 1)), `frame=${mid.frameIndex}`);

// reverse
await fpage.evaluate((t) => window.scrollTo(0, t * 0.15), travel);
await waitFor(
  async () => {
    const s = await fpage.evaluate(() => window.__sfsState || null);
    return s && s.frameIndex <= Math.round(0.15 * (frameCount - 1)) + 12;
  },
  { timeout: 10000, every: 50, desc: "file:// reverse to 15%" },
);
const back15 = await fpage.evaluate(() => window.__sfsState);
check("file:// reverse scroll moves frames backward", back15.frameIndex < mid.frameIndex, `frame=${back15.frameIndex} (was ${mid.frameIndex})`);
check("file:// no frame-0 reset while above 15%", back15.frameIndex >= Math.round(0.15 * (frameCount - 1)) - 8, `frame=${back15.frameIndex}`);

// fast jump: current position prioritized, no white flash (canvas keeps a frame)
await fpage.evaluate((t) => window.scrollTo(0, t * 0.9), travel);
const fastArrival = await waitFor(
  async () => {
    const s = await fpage.evaluate(() => window.__sfsState || null);
    return s && s.frameIndex >= Math.round(0.9 * (frameCount - 1)) - 15;
  },
  { timeout: 8000, every: 40, desc: "file:// fast jump arrival" },
);
const fpFast = shotFingerprint(await canvasShot());
check("file:// fast scroll reaches current position quickly", !!fastArrival, `frame=${fastArrival ? (await fpage.evaluate(() => window.__sfsState)).frameIndex : "stalled"}`);
check("file:// canvas never blank during fast scroll", fpFast.bytes > 6000, `pngBytes=${fpFast.bytes}`);

// zero errors
check("file:// zero page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
check("file:// zero console errors", consoleErrors.length === 0, consoleErrors.slice(0, 3).join(" | "));

await ctx.close();
await browser.close();

/* ---------------------------------------------------------------- report */
console.log("\n════════════════════════════════════════════════════════════");
if (FAIL.length === 0) {
  console.log(`  Results: ${PASS.length} passed, 0 failed`);
  console.log("  🎉 file:// smoke test passed.");
} else {
  console.log(`  Results: ${PASS.length} passed, ${FAIL.length} failed`);
  console.log("\n  Failed checks:");
  for (const f of FAIL) console.log(`   ✗ ${f}`);
  process.exitCode = 1;
}
