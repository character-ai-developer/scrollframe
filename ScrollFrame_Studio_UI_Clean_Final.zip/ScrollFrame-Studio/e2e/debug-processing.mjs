import { chromium } from "playwright";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv[2] || "http://localhost:5173";

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();

page.on("pageerror", (e) => console.log("PAGEERROR:", e.message));
page.on("console", (m) => {
  if (["error","warning","log","info"].includes(m.type())) {
    console.log(`CONSOLE[${m.type()}]:`, m.text().slice(0, 400));
  }
});
page.on("requestfailed", (r) => console.log("REQFAILED:", r.url(), r.failure()?.errorText));
page.on("response", (r) => {
  if (r.status() >= 400) console.log("HTTP", r.status(), r.url().slice(0, 200));
});

await page.goto(BASE, { waitUntil: "domcontentloaded" });
await page.click("text=New Project");
await page.waitForSelector("input[type=file]", { state: "attached" });
await page.setInputFiles("input[type=file]", join(__dirname, "fixtures", "sample.mp4"));

for (let i = 0; i < 60; i++) {
  const btn = await page.locator("button", { hasText: /Process video/ }).count();
  const disabled = await page.locator("button", { hasText: /Process video/ }).isDisabled().catch(() => true);
  if (btn > 0 && !disabled) break;
  await page.waitForTimeout(500);
}
console.log("clicking process…");
await page.locator("button", { hasText: /Process video/ }).click();

await page.waitForTimeout(3000);
console.log("overlay 'Processing video':", await page.locator("text=Processing video").count());
console.log("view 'Customize':", await page.locator("text=Customize").count());
console.log("cancel btn:", await page.locator("button", { hasText: "Cancel" }).count());

// dismiss overlay when done
for (let i = 0; i < 90; i++) {
  await page.waitForTimeout(2000);
  const done = await page.locator("text=Processing complete").count();
  const failed = await page.locator("text=Processing failed").count();
  if (done > 0) {
    const vb = page.locator("button", { hasText: "View project" });
    if (await vb.count()) { await vb.click(); }
    // inspect preview frame
    await page.waitForTimeout(1500);
    const frame = page.frames().find((f) => f.url().startsWith("blob:"));
    if (frame) {
      try {
        for (const f of page.frames()) {
          if (f.url().startsWith("blob:")) {
            try {
              const info = await f.evaluate(() => ({
                url: location.href.slice(0, 60),
                hasLF: Array.from(document.querySelectorAll("script")).map((s) => s.textContent).join("").includes("lastFrameIndex"),
                state: (window.__sfsState || {}).realFrame,
                dbgStore: (window.__sfsDebug || {}).store ? (window.__sfsDebug.store.loads + "/" + window.__sfsDebug.store.loadOk) : null,
              }));
              console.log("BLOBFRAME:", JSON.stringify(info));
            } catch (e) { console.log("BLOBFRAME EVAL FAIL", String(e.message || e).slice(0, 100)); }
          }
        }
        const scriptCheck = await frame.evaluate(() => {
          const t = Array.from(document.querySelectorAll("script")).map((s) => s.textContent).join("");
          return { hasLastFrameIndex: t.includes("lastFrameIndex"), hasDbgVer: t.includes("dbgVer"), len: t.length };
        });
        console.log("SCRIPTCHECK:", JSON.stringify(scriptCheck));
        const dbg = await frame.evaluate(async () => {
          const sfs = window.__sfsState || null;
          const dbg = window.__sfsDebug || null;
          let imgTest = null;
          try {
            const r = await fetch("about:blank").catch(() => null);
            // read config from the inlined script by re-eval: we know CONFIG is not exposed;
            // instead fetch the manifest blob via __sfsDebug? not stored. Use a trick:
            // grab the runtime config from the script tag text
            const scripts = Array.from(document.querySelectorAll("script"));
            const cfgSrc = scripts.map((s) => s.textContent).find((t) => t && t.includes("spriteManifest"));
            const cfgMatch = cfgSrc ? cfgSrc.match(/"spriteManifest":"([^"]+)"/) : null;
            if (cfgMatch) {
              const m = await (await fetch(cfgMatch[1])).json();
              const im = new Image();
              imgTest = await new Promise((res) => {
                im.onload = () => res({ ok: true, w: im.naturalWidth, h: im.naturalHeight });
                im.onerror = (e) => res({ ok: false, err: "img onerror" });
                im.src = m.files[0];
                setTimeout(() => res({ ok: false, err: "img timeout" }), 10000);
              });
            } else imgTest = { err: "config not found in scripts" };
          } catch (e) { imgTest = { err: String((e && e.message) || e).slice(0, 200) }; }
          return { sfs, dbg, imgTest };
        });
        console.log("PREVIEW STATE:", JSON.stringify(dbg).slice(0, 800));
        // scroll test
        try {
          const before = await frame.evaluate(() => ({ y: window.scrollY, animH: document.getElementById("sfs-anim").getBoundingClientRect().height, ih: window.innerHeight }));
        await frame.evaluate(() => {
          const anim = document.getElementById("sfs-anim");
          const travel = anim.getBoundingClientRect().height - window.innerHeight;
          window.scrollTo(0, travel * 0.25);
        });
        for (let k = 0; k < 10; k++) {
          await page.waitForTimeout(500);
          const mid = await frame.evaluate(() => ({ y: window.scrollY, p: (window.__sfsState || {}).progress, fi: (window.__sfsState || {}).frameIndex }));
          console.log("SCROLL25 poll", k, JSON.stringify(mid));
        }
          await frame.evaluate(() => {
            const anim = document.getElementById("sfs-anim");
            const travel = anim.getBoundingClientRect().height - window.innerHeight;
            window.scrollTo(0, travel * 0.5);
          });
          await page.waitForTimeout(1200);
          const after = await frame.evaluate(() => ({ y: window.scrollY, st: window.__sfsState }));
          console.log("SCROLLTEST before:", JSON.stringify(before), "after:", JSON.stringify({ y: after.y, fi: after.st.frameIndex, p: after.st.progress, real: after.st.realFrame }));
        } catch (e) { console.log("SCROLLTEST FAILED:", String(e.message || e).slice(0, 200)); }
      } catch (e) { console.log("PREVIEW EVAL FAILED:", String(e.message || e).slice(0, 200)); }
    } else console.log("PREVIEW FRAME NOT FOUND");
  }
  // overlay percent + stage text
  const stage = await page
    .locator("div.absolute.inset-0.z-50 >> text=/Uploading|Analyzing|Extracting|Optimizing|Generating|Creating|Complete|failed/i")
    .allTextContents()
    .catch(() => []);
  const logLines = await page.locator("div[class*=font-mono] > div").allTextContents().catch(() => []);
  console.log(`t=${i * 2}s done=${done} failed=${failed} stage="${stage[0] ?? ""}" logs=${JSON.stringify(logLines.slice(-3))}`);
  if (done > 0 || failed > 0) break;
}

await browser.close();
