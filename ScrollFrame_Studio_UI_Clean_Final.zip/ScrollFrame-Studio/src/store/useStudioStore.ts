import { create } from "zustand";
import type {
  FrameExtractionResult,
  GenerationMode,
  ProcessingSettings,
  ProjectRecord,
  SiteSettings,
  StageId,
  VideoMeta,
} from "../types";
import { DEFAULT_SITE_SETTINGS, uid } from "../types";
import { processVideo, type ModeRecommendation } from "../lib/processor";
import * as projectsDb from "../lib/projects";

export type View = "dashboard" | "upload" | "workspace";

export interface ProcessingState {
  active: boolean;
  stage: StageId;
  errorStage: StageId | null;
  percent: number;
  framesDone: number;
  framesTotal: number;
  etaSeconds: number | null;
  elapsedMs: number;
  error: string | null;
  logs: string[];
  recommendation: ModeRecommendation | null;
}

const IDLE_PROCESSING: ProcessingState = {
  active: false,
  stage: "idle",
  errorStage: null,
  percent: 0,
  framesDone: 0,
  framesTotal: 0,
  etaSeconds: null,
  elapsedMs: 0,
  error: null,
  logs: [],
  recommendation: null,
};

interface StudioState {
  view: View;
  projects: ProjectRecord[];
  activeProjectId: string | null;
  processing: ProcessingState;
  settingsOpen: boolean;
  maxFileSizeMB: number;
  maxFileSizeMBEditable: number;

  hydrate: () => Promise<void>;
  setView: (v: View) => void;
  setSettingsOpen: (open: boolean) => void;
  setMaxFileSizeMB: (mb: number) => void;
  selectProject: (id: string | null) => void;
  deleteProject: (id: string) => Promise<void>;
  updateSiteSettings: (id: string, patch: Partial<SiteSettings>) => void;
  updateProcessingSettings: (id: string, patch: Partial<ProcessingSettings>) => void;
  setMode: (id: string, mode: GenerationMode) => void;
  processVideoFile: (
    file: File,
    processingSettings: ProcessingSettings,
  ) => Promise<ProjectRecord | null>;
  cancelProcessing: () => void;
  dismissProcessing: () => void;
  clearError: () => void;
}

let abortController: AbortController | null = null;

export const useStudioStore = create<StudioState>((set, get) => ({
  view: "dashboard",
  projects: [],
  activeProjectId: null,
  processing: { ...IDLE_PROCESSING },
  settingsOpen: false,
  maxFileSizeMB: 1024,
  maxFileSizeMBEditable: 1024,

  hydrate: async () => {
    const [projects, storedMax] = await Promise.all([
      projectsDb.listProjects(),
      Promise.resolve(localStorage.getItem("sfms-max-file-mb")).then((v) =>
        v ? parseInt(v, 10) : 1024,
      ),
    ]);
    set({ projects, maxFileSizeMB: storedMax || 1024, maxFileSizeMBEditable: storedMax || 1024 });
  },

  setView: (view) => set({ view }),
  setSettingsOpen: (settingsOpen) => set({ settingsOpen }),

  setMaxFileSizeMB: (mb) => {
    const clamped = Math.max(10, Math.min(4096, Math.round(mb)));
    localStorage.setItem("sfms-max-file-mb", String(clamped));
    set({ maxFileSizeMB: clamped, maxFileSizeMBEditable: clamped });
  },

  selectProject: (id) => {
    if (id && !get().projects.some((p) => p.id === id)) return;
    set({ activeProjectId: id, view: id ? "workspace" : "dashboard" });
  },

  deleteProject: async (id) => {
    await projectsDb.deleteProject(id);
    set((s) => ({
      projects: s.projects.filter((p) => p.id !== id),
      activeProjectId: s.activeProjectId === id ? null : s.activeProjectId,
      view: s.activeProjectId === id ? "dashboard" : s.view,
    }));
  },

  updateSiteSettings: (id, patch) => {
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === id ? { ...p, siteSettings: { ...p.siteSettings, ...patch }, updatedAt: Date.now() } : p,
      ),
    }));
    const p = get().projects.find((x) => x.id === id);
    if (p) void projectsDb.saveProject(p);
  },

  updateProcessingSettings: (id, patch) => {
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === id ? { ...p, processingSettings: { ...p.processingSettings, ...patch }, updatedAt: Date.now() } : p,
      ),
    }));
    const p = get().projects.find((x) => x.id === id);
    if (p) void projectsDb.saveProject(p);
  },

  setMode: (id, mode) => {
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === id ? { ...p, processingSettings: { ...p.processingSettings, mode }, updatedAt: Date.now() } : p,
      ),
    }));
    const p = get().projects.find((x) => x.id === id);
    if (p) void projectsDb.saveProject(p);
  },

  processVideoFile: async (file, processingSettings) => {
    const existing = get().processing;
    if (existing.active) return null;

    abortController = new AbortController();
    const signal = abortController.signal;
    const t0 = performance.now();

    set({
      view: "workspace",
      processing: {
        ...IDLE_PROCESSING,
        active: true,
        stage: "analyzing",
        elapsedMs: 0,
      },
    });

    const pushLog = (line: string) =>
      set((s) => ({ processing: { ...s.processing, logs: [...s.processing.logs.slice(-120), line] } }));

    const progressTimer = window.setInterval(() => {
      set((s) => {
        if (!s.processing.active) return s;
        return {
          processing: { ...s.processing, elapsedMs: performance.now() - t0 },
        };
      });
    }, 500);

    try {
      const result = await processVideo(
        file,
        processingSettings,
        {
          onProgress: (p) =>
            set((s) => ({
              processing: {
                ...s.processing,
                stage: stageFromPercent(p.percent, s.processing.stage),
                percent: p.percent,
                framesDone: p.framesDone,
                framesTotal: p.framesTotal,
                etaSeconds: p.etaSeconds,
                elapsedMs: performance.now() - t0,
              },
            })),
          onRecommendation: (recommendation) =>
            set((s) => ({ processing: { ...s.processing, recommendation } })),
          onLog: pushLog,
        },
        signal,
      );

      const project = await finalizeProject(file, processingSettings, result);

      set((s) => ({
        projects: [project, ...s.projects.filter((p) => p.id !== project.id)],
        activeProjectId: project.id,
        processing: {
          ...s.processing,
          active: false,
          stage: "complete",
          percent: 100,
        framesDone: result.frameCount,
        framesTotal: result.frameCount,
          etaSeconds: 0,
          elapsedMs: performance.now() - t0,
        },
      }));
      void projectsDb.saveProject(project);
      return project;
    } catch (err) {
      const message =
        err instanceof DOMException && err.name === "AbortError"
          ? "Processing was cancelled."
          : err instanceof Error
            ? err.message
            : String(err);
      set((s) => ({
        processing: {
          ...s.processing,
          active: false,
          stage: "error",
          errorStage: s.processing.stage === "error" ? "analyzing" : s.processing.stage,
          percent: s.processing.percent,
          error: message,
        },
      }));
      return null;
    } finally {
      window.clearInterval(progressTimer);
    }
  },

  cancelProcessing: () => {
    abortController?.abort();
  },

  dismissProcessing: () => set({ processing: { ...IDLE_PROCESSING } }),

  clearError: () => set({ processing: { ...IDLE_PROCESSING } }),
}));

function stageFromPercent(percent: number, current: StageId): StageId {
  if (percent < 3) return "uploading";
  if (percent < 8) return "analyzing";
  if (percent < 74) return "extracting";
  if (percent < 89) return "optimizing";
  if (percent < 92) return "generating";
  if (percent < 100) return "zipping";
  return "complete";
}

async function finalizeProject(
  file: File,
  processingSettings: ProcessingSettings,
  result: Awaited<ReturnType<typeof processVideo>>,
): Promise<ProjectRecord> {
  const meta: VideoMeta = result.meta;
  const now = Date.now();
  const existing = useStudioStore
    .getState()
    .projects.find((p) => p.videoMeta.filename === file.name && p.createdAt > now - 1000);
  const id = existing?.id ?? uid();

  const extraction: FrameExtractionResult = {
    count: result.frameCount,
    fps: result.effectiveFps,
    width: result.outputWidth,
    height: result.outputHeight,
    framesBlob: result.framesBlob,
    posterBlob: result.posterBlob,
    totalBytes: result.totalBytes,
    sourceBytes: file.size,
    timeMs: result.timeMs,
    format: result.format,
    mode: result.mode,
    estimatedTotalBytes: result.totalBytes + 90 * 1024,
    frames: result.frames ? { blobs: result.frames.blobs } : null,
    videoBlob: result.videoBlob,
  };

  return {
    id,
    name: meta.filename.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").slice(0, 40) || "Untitled",
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    videoMeta: meta,
    processingSettings,
    siteSettings: { ...DEFAULT_SITE_SETTINGS },
    result: extraction,
    modeRecommendation: result.recommendation,
  };
}
