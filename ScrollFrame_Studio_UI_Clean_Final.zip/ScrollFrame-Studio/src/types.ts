/** Shared domain types for ScrollFrame Studio. */

export type ImageFormat = "webp" | "jpeg" | "png";

export type GenerationMode = "frames" | "video";

export type PresetId = "lightweight" | "balanced" | "high";

export type FitMode = "contain" | "cover";

export type PlaybackStyle = "scroll" | "autoplay";

export interface ProcessingSettings {
  preset: PresetId;
  fps: number; // extraction FPS (target)
  maxFrames: number;
  imageFormat: ImageFormat;
  imageQuality: number; // 0..100
  maxResolution: number; // longest edge, px
  mode: GenerationMode; // "frames" | "video"
}

export interface SiteSettings {
  // look
  backgroundColor: string;
  backgroundGradientFrom: string;
  backgroundGradientTo: string;
  backgroundStyle: "solid" | "gradient" | "dark-overlay";
  textColor: string;
  accentColor: string;
  fontFamily: "inter" | "system" | "serif";
  // animation
  animationDuration: number; // seconds of scrolling
  scrollSensitivity: number; // 0.5..2
  startOffset: number; // vh
  endOffset: number; // vh
  easing: "linear" | "ease-in-out" | "smoothstep";
  smoothing: number; // 0..1 lerp factor for scroll smoothing
  reverseOnScrollUp: boolean;
  fitMode: FitMode;
  // optional UI
  showLoadingScreen: boolean;
  showScrollIndicator: boolean;
  showProgress: boolean;
  showPlayPause: boolean;
  showFullscreen: boolean;
  showSound: boolean;
  introText: string;
  outroText: string;
}

export interface VideoMeta {
  filename: string;
  fileSize: number;
  duration: number; // seconds
  width: number;
  height: number;
  fps: number;
  mimeType: string;
}

export interface SpriteManifest {
  version: 1;
  count: number;
  batchSize: number;
  perRow: number;
  tileW: number;
  tileH: number;
  files: string[];
  format: ImageFormat;
}

export interface FrameOutput {
  blobs: Blob[]; // one optimized image per frame, in playback order (frames mode)
}

export interface FrameExtractionResult {
  count: number;
  fps: number;
  width: number;
  height: number;
  framesBlob: Blob | null; // ZIP archive of optimized frames (frames mode)
  posterBlob: Blob;
  totalBytes: number;
  sourceBytes: number;
  timeMs: number;
  format: ImageFormat;
  mode: GenerationMode;
  estimatedTotalBytes: number;
  frames: FrameOutput | null;
  videoBlob: Blob | null; // optimized video (video mode)
}

export interface ProjectRecord {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  videoMeta: VideoMeta;
  processingSettings: ProcessingSettings;
  siteSettings: SiteSettings;
  result: FrameExtractionResult;
  modeRecommendation?: { mode: GenerationMode; reason: string };
}

export type StageId =
  | "idle"
  | "uploading"
  | "analyzing"
  | "extracting"
  | "optimizing"
  | "generating"
  | "zipping"
  | "complete"
  | "error";

export interface StageInfo {
  id: StageId;
  label: string;
}

export const STAGES: StageInfo[] = [
  { id: "uploading", label: "Uploading" },
  { id: "analyzing", label: "Analyzing video" },
  { id: "extracting", label: "Extracting frames" },
  { id: "optimizing", label: "Optimizing frames" },
  { id: "generating", label: "Generating website" },
  { id: "zipping", label: "Creating ZIP" },
  { id: "complete", label: "Complete" },
];

export const STAGE_INDEX: Record<StageId, number> = {
  idle: -1,
  uploading: 0,
  analyzing: 1,
  extracting: 2,
  optimizing: 3,
  generating: 4,
  zipping: 5,
  complete: 6,
  error: 7,
};

export const MODE_LABEL: Record<GenerationMode, string> = {
  frames: "Frame mode",
  video: "Video mode",
};

export const DEFAULT_PROCESSING: ProcessingSettings = {
  preset: "balanced",
  fps: 30,
  maxFrames: 900,
  imageFormat: "webp",
  imageQuality: 82,
  maxResolution: 1280,
  mode: "frames",
};

export const PRESET_DEFS: {
  id: PresetId;
  name: string;
  desc: string;
  fps: number;
  quality: number;
  maxResolution: number;
  maxFrames: number;
}[] = [
  {
    id: "lightweight",
    name: "Lightweight",
    desc: "Smallest output — 12–15 FPS",
    fps: 14,
    quality: 70,
    maxResolution: 960,
    maxFrames: 360,
  },
  {
    id: "balanced",
    name: "Balanced",
    desc: "Great quality / size trade-off — 30 FPS",
    fps: 30,
    quality: 84,
    maxResolution: 1280,
    maxFrames: 900,
  },
  {
    id: "high",
    name: "High Quality",
    desc: "Cinematic smoothness — 30 FPS",
    fps: 30,
    quality: 90,
    maxResolution: 1600,
    maxFrames: 1080,
  },
];

export const MAX_FILE_SIZE = 1024 * 1024 * 1024; // 1 GB hard cap (browser-safe default)
export const MAX_FILE_SIZE_MB = Math.round(MAX_FILE_SIZE / (1024 * 1024));

export const ACCEPTED_VIDEO_TYPES = [
  "video/mp4",
  "video/webm",
  "video/quicktime", // .mov
  "video/x-m4v",
  "video/ogg",
  "video/x-msvideo", // .avi
  "video/x-matroska", // .mkv
  "application/octet-stream", // some browsers report this for .mov/.mkv
];

export const ACCEPTED_EXTENSIONS = [
  ".mp4",
  ".webm",
  ".mov",
  ".m4v",
  ".ogv",
  ".ogg",
  ".avi",
  ".mkv",
];

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  backgroundColor: "#f0ede4",
  backgroundGradientFrom: "#f0ede4",
  backgroundGradientTo: "#e4e0d3",
  backgroundStyle: "solid",
  textColor: "#161616",
  accentColor: "#ff4d00",
  fontFamily: "system",
  animationDuration: 12,
  scrollSensitivity: 1,
  startOffset: 0,
  endOffset: 0,
  easing: "linear",
  smoothing: 0,
  reverseOnScrollUp: true,
  fitMode: "cover",
  showLoadingScreen: true,
  showScrollIndicator: true,
  showProgress: true,
  showPlayPause: false,
  showFullscreen: false,
  showSound: false,
  introText: "",
  outroText: "",
};

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const v = bytes / Math.pow(1024, i);
  return `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${units[i]}`;
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "id-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

/** Rough time estimate for the whole pipeline based on video size + settings. */
export function estimateProcessingSeconds(
  videoBytes: number,
  durationSec: number,
  frameCount: number,
  quality: number,
): number {
  const encodeMs = frameCount * (0.02 * (quality / 82) + 0.012);
  const muxMs = frameCount * 0.003;
  const seekMs = durationSec * 18;
  const wasmMs = Math.max(450, videoBytes / (4 * 1024 * 1024) * 350);
  return Math.ceil((encodeMs + muxMs + seekMs + wasmMs) / 1000);
}
