import { useStudioStore } from "./store/useStudioStore";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import UploadView from "./components/UploadView";
import WorkspaceView from "./components/WorkspaceView";
import ProcessingOverlay from "./components/ProcessingOverlay";
import SettingsModal from "./components/SettingsModal";

export default function App() {
  const view = useStudioStore((s) => s.view);
  const processing = useStudioStore((s) => s.processing);
  const showOverlay = processing.active || processing.stage === "complete" || processing.stage === "error";

  return (
    <div className="flex h-full overflow-hidden bg-paper text-ink">
      <Sidebar />
      <main className="relative flex-1 overflow-hidden">
        {view === "dashboard" && <Dashboard />}
        {view === "upload" && <UploadView />}
        {view === "workspace" && <WorkspaceView />}
        {showOverlay && <ProcessingOverlay />}
        <SettingsModal />
      </main>
    </div>
  );
}
