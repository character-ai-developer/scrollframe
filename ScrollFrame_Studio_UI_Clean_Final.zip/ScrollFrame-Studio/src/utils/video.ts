import type { VideoMeta } from "../types";
import { ACCEPTED_EXTENSIONS, MAX_FILE_SIZE } from "../types";

export class VideoValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "VideoValidationError";
  }
}

export function isVideoFile(file: File): boolean {
  const ext = "." + (file.name.split(".").pop() || "").toLowerCase();
  if (ACCEPTED_EXTENSIONS.includes(ext)) return true;
  if (file.type.startsWith("video/")) return true;
  return false;
}

export function validateVideoFile(file: File, maxBytes = MAX_FILE_SIZE): void {
  if (!file) throw new VideoValidationError("No file selected.");
  if (!isVideoFile(file)) {
    throw new VideoValidationError(
      `"${file.name}" does not look like a video. Supported formats: MP4, WebM, MOV, M4V, OGV, AVI, MKV.`,
    );
  }
  if (file.size > maxBytes) {
    throw new VideoValidationError(
      `File is ${(file.size / (1024 * 1024)).toFixed(0)} MB — larger than the ${(maxBytes / (1024 * 1024)).toFixed(0)} MB limit configured for this instance.`,
    );
  }
  if (file.size === 0) {
    throw new VideoValidationError("This file is empty (0 bytes).");
  }
}

/**
 * Estimate the frame rate of an MP4/MOV/WebM by scanning container metadata.
 * Fast (no playback). Returns null when unknown.
 */
export async function probeFpsFromBytes(file: File): Promise<number | null> {
  try {
    const head = file.slice(0, Math.min(512 * 1024, file.size));
    const tail = file.slice(Math.max(0, file.size - 1024 * 1024));
    const [headBuf, tailBuf] = await Promise.all([head.arrayBuffer(), tail.arrayBuffer()]);
    const bytes = new Uint8Array(headBuf.byteLength + tailBuf.byteLength);
    bytes.set(new Uint8Array(headBuf), 0);
    bytes.set(new Uint8Array(tailBuf), headBuf.byteLength);
    const ascii = new TextDecoder("latin1").decode(bytes);

    // --- MP4 / MOV: look for the `mdhd` (media header) box ---
    let idx = ascii.indexOf("mdhd");
    while (idx !== -1) {
      try {
        const version = bytes[idx + 4];
        let off = idx + 8;
        if (version === 1) off += 16;
        else off += 8;
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const timescale = view.getUint32(off);
        const duration = version === 1 ? Number(view.getBigUint64(off + 4)) : view.getUint32(off + 4);
        if (timescale > 0 && duration > 0) {
          const fps = duration / timescale;
          if (fps > 1 && fps < 240) return Math.round(fps * 100) / 100;
        }
      } catch {
        /* keep scanning */
      }
      idx = ascii.indexOf("mdhd", idx + 1);
    }

    // --- WebM: EBML element 0x4489 = Segment > Info > Duration (float seconds) ---
    const dur = findWebmFloat(bytes, 0x4489);
    if (dur !== null && dur > 0.05 && dur < 60 * 60 * 24) return 30;
  } catch {
    /* ignore probe errors */
  }
  return null;
}

/** Minimal EBML float search: ID bytes + size header + 8-byte little-endian float. */
function findWebmFloat(bytes: Uint8Array, id: number): number | null {
  const idBytes = [(id >> 16) & 0xff, (id >> 8) & 0xff, id & 0xff];
  for (let i = 0; i + 12 < bytes.length; i++) {
    if (bytes[i] !== idBytes[0] || bytes[i + 1] !== idBytes[1] || bytes[i + 2] !== idBytes[2]) continue;
    let size = 0;
    const sizeByte = bytes[i + 3];
    const lenBytes = sizeByte & 0x07;
    if (lenBytes === 0 || lenBytes > 4) continue;
    for (let b = 0; b < lenBytes; b++) size = size * 256 + bytes[i + 4 + b];
    const valueOff = i + 4 + lenBytes;
    if (valueOff + 8 > bytes.length) continue;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    return view.getFloat64(valueOff, true);
  }
  return null;
}

/** Decode metadata using the browser's native video demuxer + container probe. */
export function probeVideoMeta(file: File): Promise<VideoMeta> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;

    let settled = false;
    const timer = window.setTimeout(() => {
      if (!settled) {
        settled = true;
        cleanup();
        reject(new Error("Timed out while reading video metadata. The file may be corrupted or use an unsupported codec."));
      }
    }, 20000);

    const cleanup = () => {
      window.clearTimeout(timer);
      URL.revokeObjectURL(url);
      video.removeAttribute("src");
      video.load();
    };

    const finish = (meta?: VideoMeta, err?: Error) => {
      if (settled) return;
      settled = true;
      cleanup();
      if (err) reject(err);
      else resolve(meta as VideoMeta);
    };

    video.onerror = () =>
      finish(undefined, new Error("The browser could not decode this video. It may be corrupted or use an unsupported codec (e.g. HEVC on this browser)."));

    video.onloadedmetadata = () => {
      const base: VideoMeta = {
        filename: file.name,
        fileSize: file.size,
        duration: Number.isFinite(video.duration) ? video.duration : 0,
        width: video.videoWidth,
        height: video.videoHeight,
        fps: 0,
        mimeType: file.type || "video/mp4",
      };
      if (!base.width || !base.height || !base.duration) {
        finish(undefined, new Error("Could not read video dimensions/duration. The file may be corrupted."));
        return;
      }
      probeFpsFromBytes(file)
        .then((fps) => finish({ ...base, fps: fps ?? 30 }))
        .catch(() => finish({ ...base, fps: 30 }));
    };

    video.src = url;
    video.load();
  });
}

/** Read a File into an ArrayBuffer with a size guard. */
export async function readAsArrayBuffer(file: File, maxBytes = MAX_FILE_SIZE): Promise<ArrayBuffer> {
  if (file.size > maxBytes) {
    throw new Error(
      `File is ${(file.size / (1024 * 1024)).toFixed(0)} MB — above the ${(maxBytes / (1024 * 1024)).toFixed(0)} MB processing limit.`,
    );
  }
  return await file.arrayBuffer();
}

export function createObjectURL(blob: Blob): string {
  return URL.createObjectURL(blob);
}

export function revokeObjectURL(url: string | null | undefined): void {
  if (url) URL.revokeObjectURL(url);
}

export function aspectRatioLabel(w: number, h: number): string {
  if (!w || !h) return "—";
  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
  const g = gcd(Math.round(w), Math.round(h));
  return `${(w / h).toFixed(2)} : 1 (${Math.round(w) / g}:${Math.round(h) / g})`;
}
