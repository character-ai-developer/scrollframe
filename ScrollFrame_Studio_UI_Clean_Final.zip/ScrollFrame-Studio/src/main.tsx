import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { useStudioStore } from "./store/useStudioStore";

// hydrate recent projects from IndexedDB before first paint
void useStudioStore.getState().hydrate();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
