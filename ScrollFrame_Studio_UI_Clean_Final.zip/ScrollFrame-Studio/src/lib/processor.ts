import JSZip from "jszip";
import { loadFFmpeg } from "./ffmpegPool";
import type { ProcessingSettings, VideoMeta, GenerationMode, ImageFormat, FrameExtractionResult, FrameOutput } from "../types";
import { clamp } from "../types";
import { probeVideoMeta, validateVideoFile } from "../utils/video";

export interface ModeRecommendation {
  mode: GenerationMode;
  reason: string;
}

export interface ProgressUpdate {
  percent: number; // 0..100
  stage: string;
  framesDone: number;
  framesTotal: number;
  etaSeconds: number | null;
  elapsedMs: number;
}

export interface ProcessCallbacks {
  onProgress: (p: ProgressUpdate) => void;
  onRecommendation: (r: ModeRecommendation) => void;
  onLog?: (line: string) => void;
}

export interface SpriteOutput {
  blobs: Blob[]; // internal tile-packed sheets used to slice individual frames
}

export interface ProcessedOutput {
  meta: VideoMeta;
  mode: GenerationMode;
  recommendation: ModeRecommendation;
  frameCount: number;
  effectiveFps: number;
  outputWidth: number;
  outputHeight: number;
  format: ImageFormat;
  posterBlob: Blob;
  framesBlob: Blob | null; // ZIP of individual frames (frames mode)
  framesZip: JSZip | null;
  frames: FrameOutput | null;
  videoBlob: Blob | null; // optimized video (video mode)
  totalBytes: number;
  timeMs: number;
}

export class ProcessingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ProcessingError";
  }
}

const FRAME_EXT: Record<ImageFormat, string> = { webp: "webp", jpeg: "jpg", png: "png" };
const IMAGE_MIME: Record<ImageFormat, string> = { webp: "image/webp", jpeg: "image/jpeg", png: "image/png" };

function frameFilename(index: number, format: ImageFormat): string {
  return `frame_${String(index + 1).padStart(5, "0")}.${FRAME_EXT[format]}`;
}

function pickScale(meta: VideoMeta, maxRes: number): { w: number; h: number } {
  if (!meta.width || !meta.height) return { w: 960, h: 540 };
  const longest = Math.max(meta.width, meta.height);
  if (longest <= maxRes) {
    return { w: even(meta.width), h: even(meta.height) };
  }
  const k = maxRes / longest;
  return { w: even(meta.width * k), h: even(meta.height * k) };
}

function even(n: number): number {
  return Math.max(16, Math.round(n / 2) * 2);
}

function clampFps(fps: number): number {
  return clamp(Math.round(fps * 100) / 100, 1, 60);
}

/** Recommend the best generation mode for this video + settings. */
export function recommendMode(meta: VideoMeta, settings: ProcessingSettings): ModeRecommendation {
  const fps = clampFps(settings.fps);
  const estimatedFrames = Math.round(meta.duration * fps);
  const pixels = meta.width * meta.height;
  const longVideo = meta.duration > 45;
  const tooManyFrames = estimatedFrames > 1200 || meta.duration * 60 > 1800;
  const hugeResolution = pixels > 3840 * 2160 * 0.75 && meta.duration > 20;

  if (longVideo || tooManyFrames || hugeResolution) {
    const reasons: string[] = [];
    if (longVideo) reasons.push(`${meta.duration.toFixed(0)}s is a long video`);
    if (tooManyFrames) reasons.push(`≈${estimatedFrames} frames would be extracted`);
    if (hugeResolution) reasons.push("very high resolution");
    return {
      mode: "video",
      reason:
        `Video Mode recommended: ${reasons.join(" · ")}. Native playback stays smooth ` +
        `with far less memory, at the cost of less precise scrubbing.`,
    };
  }
  return {
    mode: "frames",
    reason:
      `Frame Mode recommended: ${Math.round(meta.duration * fps)} frames at ${fps} FPS give ` +
      `frame-perfect, memory-friendly scrubbing both directions.`,
  };
}

/**
 * Encode args for a given image format + quality.
 */
function imageEncArgs(format: ImageFormat, quality: number): string[] {
  if (format === "jpeg") {
    return ["-c:v", "mjpeg", "-q:v", String(Math.round(31 - (quality / 100) * 28)), "-pix_fmt", "yuv420p"];
  }
  if (format === "webp") {
    return ["-c:v", "libwebp", "-q:v", String(quality), "-compression_level", "5"];
  }
  return ["-c:v", "png", "-compression_level", "6", "-pix_fmt", "rgba"];
}

export async function processVideo(
  file: File,
  settings: ProcessingSettings,
  callbacks: ProcessCallbacks,
  signal?: AbortSignal,
): Promise<ProcessedOutput> {
  const started = performance.now();
  const throwIfAborted = () => {
    if (signal?.aborted) throw new DOMException("Processing cancelled", "AbortError");
  };

  const progress = (percent: number, stage: string, framesDone: number, framesTotal: number, eta: number | null) => {
    callbacks.onProgress({
      percent: clamp(percent, 0, 100),
      stage,
      framesDone,
      framesTotal,
      etaSeconds: eta,
      elapsedMs: performance.now() - started,
    });
  };

  // ---------------------------------------------------------------- upload
  progress(1, "Reading video into the browser…", 0, 0, null);
  validateVideoFile(file);
  await new Promise((r) => setTimeout(r, 50));
  const inputData = await file.arrayBuffer();
  callbacks.onLog?.(`Loaded ${(file.size / (1024 * 1024)).toFixed(1)} MB into memory (local, never uploaded).`);

  // --------------------------------------------------------------- analyze
  progress(3, "Analyzing video…", 0, 0, null);
  const meta = await probeVideoMeta(file);
  throwIfAborted();

  const ffmpeg = await loadFFmpeg();
  throwIfAborted();
  await ffmpeg.writeFile("input.bin", new Uint8Array(inputData));

  // exact fps from container
  const logs: string[] = [];
  const onLog = ({ message }: { message: string }) => {
    logs.push(message);
    if (logs.length > 80) logs.shift();
  };
  ffmpeg.on("log", onLog);
  try {
    await ffmpeg.exec(["-hide_banner", "-i", "input.bin", "-map", "0:v:0", "-c", "copy", "-f", "null", "-"], 30000);
  } catch {
    /* stderr parsed below; a decode error here is non-fatal */
  }
  const fullLog = logs.join("\n");
  const fpsMatch = fullLog.match(/([\d.]+)\s*fps/);
  const containerFps = fpsMatch ? parseFloat(fpsMatch[1]) : meta.fps || 30;
  const realFps = clampFps(containerFps > 0 && containerFps < 240 ? containerFps : 30);
  const realDuration = meta.duration > 0 ? meta.duration : 0;

  if (!realDuration || !meta.width) {
    throw new ProcessingError(
      "Could not analyze this video (no readable video track). It may be corrupted or use an unsupported codec.",
    );
  }

  const { w: outW, h: outH } = pickScale(meta, settings.maxResolution);

  const targetFps = clampFps(settings.fps);
  let effectiveFps = targetFps;
  if (settings.maxFrames > 0) {
    effectiveFps = clampFps(Math.min(targetFps, settings.maxFrames / realDuration));
  }
  const totalFrames = Math.max(1, Math.round(realDuration * effectiveFps));

  // ------------------------------------------------------- mode decision
  const recommendation = recommendMode(meta, settings);
  callbacks.onRecommendation(recommendation);
  const mode: GenerationMode =
    settings.mode === "video" || settings.mode === "frames" ? settings.mode : recommendation.mode;
  callbacks.onLog?.(
    `Mode: ${mode === "frames" ? "Frame Mode" : "Video Mode"} · ${totalFrames} frames · ${effectiveFps} FPS · ${outW}×${outH}`,
  );

  const format = settings.imageFormat;
  const quality = clamp(Math.round(settings.imageQuality), 1, 100);

  // ------------------------------------------------------- video mode path
  if (mode === "video") {
    progress(8, "Preparing video for export…", 0, totalFrames, null);
    const videoBlob = await prepareVideoForExport(ffmpeg, outW, outH, quality, (p, stage) =>
      progress(8 + p * 72, stage, 0, totalFrames, null),
    );
    throwIfAborted();
    progress(82, "Extracting poster frame…", 0, totalFrames, null);
    const posterBlob = await extractPoster(ffmpeg, outW, outH, format, quality);
    throwIfAborted();
    const totalBytes = videoBlob.size + posterBlob.size + 64 * 1024;
    callbacks.onLog?.(`Optimized video: ${(videoBlob.size / 1024 / 1024).toFixed(1)} MB (was ${(file.size / 1024 / 1024).toFixed(1)} MB).`);
    progress(100, "Complete", 0, totalFrames, 0);
    return {
      meta,
      mode,
      recommendation,
      frameCount: totalFrames,
      effectiveFps,
      outputWidth: outW,
      outputHeight: outH,
      format,
      posterBlob,
      framesBlob: null,
      framesZip: null,
      frames: null,
      videoBlob,
      totalBytes,
      timeMs: performance.now() - started,
    };
  }

  // ------------------------------------------------------- frames mode path
  // Tile-based extraction: ffmpeg packs the frames into sprite sheets directly
  // (one exec, no per-frame files in MEMFS). The sheets ARE the site's sprite
  // assets; individual frames are sliced from them in JS for assets/frames.
  progress(8, "Extracting frames…", 0, totalFrames, null);

  // sheet grid: keep each decoded sheet ≤ ~8 MP
  const perRow = outW >= 1400 ? 2 : outW >= 1000 ? 3 : outW >= 700 ? 4 : 5;
  const maxRows = Math.max(1, Math.floor(8_000_000 / (perRow * outW * outH)));
  const framesPerSheet = Math.max(4, Math.min(60, perRow * maxRows));
  const sheetCount = Math.ceil(totalFrames / framesPerSheet);

  const sheetArgs = [
    "-hide_banner",
    "-loglevel", "error",
    "-i", "input.bin",
    "-an",
    "-vf",
    `scale=${outW}:${outH}:flags=lanczos,fps=${effectiveFps},tile=${perRow}x${Math.ceil(framesPerSheet / perRow)}`,
    "-frames:v", String(Math.max(1, sheetCount)),
    ...imageEncArgs(format, quality),
    "-start_number", "0",
    "-y",
    "sheet_%03d." + FRAME_EXT[format],
  ];

  let lastFfProg = 0;
  const onFramesProgress = ({ progress: p }: { progress: number }) => {
    lastFfProg = Number.isFinite(p) ? p : 0;
  };
  ffmpeg.on("progress", onFramesProgress);
  const reportExtraction = () => {
    const done = Math.min(totalFrames, Math.round(lastFfProg * totalFrames));
    progress(8 + (done / totalFrames) * 66, `Extracting frames — ${done}/${totalFrames}`, done, totalFrames, null);
  };
  const ticker = window.setInterval(reportExtraction, 400);

  try {
    await ffmpeg.exec(sheetArgs, 600000);
  } catch (err) {
    window.clearInterval(ticker);
    const msg = err instanceof Error ? err.message : String(err);
    throw new ProcessingError(
      `Frame extraction failed. ${msg}` +
        (logs.join("\n").includes("not enough memory") ? " The browser ran out of memory — try a lower preset or shorter video." : ""),
    );
  }
  window.clearInterval(ticker);
  ffmpeg.off("progress", onFramesProgress);
  throwIfAborted();

  // read the sheets (loop until the FS reports no more sheets)
  progress(74, "Reading sprite sheets…", 0, totalFrames, null);
  const sheetBlobs: Blob[] = [];
  for (let s = 0; ; s++) {
    let data: Uint8Array;
    try {
      data = (await ffmpeg.readFile(`sheet_${String(s).padStart(3, "0")}.${FRAME_EXT[format]}`)) as Uint8Array;
    } catch {
      break; // no more sheets — normal end
    }
    sheetBlobs.push(new Blob([data], { type: IMAGE_MIME[format] }));
    callbacks.onLog?.(`Sheet ${s + 1} read (${(data.length / 1024).toFixed(0)} KB).`);
  }
  if (sheetBlobs.length === 0) {
    throw new ProcessingError("Frame extraction produced no output. The video may use an unsupported codec.");
  }

  // ------------------------------------------------------------ optimize
  // slice individual frames out of the sheets + verify every frame decodes
  const optimizeStart = 74;
  const optimizeSpan = 14;
  const sliced = await sliceFrames(
    sheetBlobs,
    outW,
    outH,
    perRow,
    Math.ceil(framesPerSheet / perRow),
    totalFrames,
    format,
    quality,
    (done) => progress(optimizeStart + (done / totalFrames) * optimizeSpan, `Optimizing frames — ${done}/${totalFrames}`, done, totalFrames, null),
  );
  throwIfAborted();

  progress(89, "Generating poster…", totalFrames, totalFrames, null);
  const posterBlob = sliced.frames[0];

  progress(91, "Assembling project…", totalFrames, totalFrames, null);
  const framesZip = new JSZip();
  const framesFolder = framesZip.folder("assets/frames")!;
  sliced.frames.forEach((blob, i) => framesFolder.file(frameFilename(i, format), blob));

  const frames: FrameOutput = { blobs: sliced.frames };
  const sheetBytes = sheetBlobs.reduce((s, b) => s + b.size, 0);

  const framesBlob = await framesZip.generateAsync({ type: "blob", compression: "STORE", streamFiles: true });
  const frameBytes = sliced.frames.reduce((s, b) => s + b.size, 0);
  const totalBytes = frameBytes + posterBlob.size + 80 * 1024;
  const timeMs = performance.now() - started;
  callbacks.onLog?.(
    `${totalFrames} frames · ${(frameBytes / 1024 / 1024).toFixed(2)} MB frames · ${(sheetBytes / 1024 / 1024).toFixed(2)} MB extraction tiles · ${(timeMs / 1000).toFixed(1)}s`,
  );
  progress(100, "Complete", totalFrames, totalFrames, 0);
  return {
    meta,
    mode,
    recommendation,
    frameCount: totalFrames,
    effectiveFps,
    outputWidth: outW,
    outputHeight: outH,
    format,
    posterBlob,
    framesBlob,
    framesZip,
    frames,
    videoBlob: null,
    totalBytes,
    timeMs,
  };
}

/* ------------------------------------------------------------------ utils */

function decodeToImage(blob: Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("A generated frame could not be decoded (corrupt encode)."));
    };
    img.src = url;
  });
}

/**
 * Slice individual frames out of tile-packed sprite sheets and re-encode each
 * cell. Also validates that every frame decodes correctly.
 */
async function sliceFrames(
  sheetBlobs: Blob[],
  frameW: number,
  frameH: number,
  perRow: number,
  rows: number,
  totalFrames: number,
  format: ImageFormat,
  quality: number,
  onProgress?: (done: number) => void,
): Promise<{ frames: Blob[] }> {
  const sheetCanvas = document.createElement("canvas");
  sheetCanvas.width = perRow * frameW;
  sheetCanvas.height = rows * frameH;
  const sctx = sheetCanvas.getContext("2d");
  if (!sctx) throw new ProcessingError("Canvas 2D is not available in this browser.");

  const cell = document.createElement("canvas");
  cell.width = frameW;
  cell.height = frameH;
  const cctx = cell.getContext("2d");
  if (!cctx) throw new ProcessingError("Canvas 2D is not available in this browser.");

  const mime = IMAGE_MIME[format];
  const toBlob = (c: HTMLCanvasElement): Promise<Blob> =>
    new Promise((resolve, reject) => {
      c.toBlob(
        (b) => (b ? resolve(b) : reject(new ProcessingError("Frame encoding failed (browser rejected the image)."))),
        mime,
        format === "jpeg" ? Math.max(0.3, quality / 100) : quality / 100,
      );
    });

  const frames: Blob[] = [];
  let done = 0;
  for (let s = 0; s < sheetBlobs.length; s++) {
    const img = await decodeToImage(sheetBlobs[s]);
    sctx.clearRect(0, 0, sheetCanvas.width, sheetCanvas.height);
    sctx.drawImage(img, 0, 0);
    const startIdx = s * (perRow * rows);
    const n = Math.min(perRow * rows, totalFrames - startIdx);
    for (let i = 0; i < n; i++) {
      const col = i % perRow;
      const row = Math.floor(i / perRow);
      cctx.clearRect(0, 0, frameW, frameH);
      cctx.drawImage(sheetCanvas, col * frameW, row * frameH, frameW, frameH, 0, 0, frameW, frameH);
      const blob = await toBlob(cell);
      frames.push(blob);
      done++;
      if (onProgress && done % 5 === 0) onProgress(done);
    }
    if (onProgress) onProgress(done);
  }
  if (frames.length !== totalFrames) {
    throw new ProcessingError(
      `Expected ${totalFrames} frames but sliced ${frames.length}. The video may have an unusual timebase.`,
    );
  }
  return { frames };
}

async function extractPoster(
  ffmpeg: Awaited<ReturnType<typeof loadFFmpeg>>,
  w: number,
  h: number,
  format: ImageFormat,
  quality: number,
): Promise<Blob> {
  await ffmpeg.exec(
    ["-hide_banner", "-loglevel", "error", "-ss", "0", "-i", "input.bin", "-an", "-frames:v", "1",
      "-vf", `scale=${w}:${h}:flags=lanczos`, ...imageEncArgs(format, quality), "-y", "poster." + FRAME_EXT[format]],
    120000,
  );
  const data = await ffmpeg.readFile("poster." + FRAME_EXT[format]);
  return new Blob([data], { type: IMAGE_MIME[format] });
}

async function prepareVideoForExport(
  ffmpeg: Awaited<ReturnType<typeof loadFFmpeg>>,
  w: number,
  h: number,
  quality: number,
  onProgress: (pct: number, stage: string) => void,
): Promise<Blob> {
  const crf = Math.round(clamp(34 - (quality / 100) * 16, 18, 40));

  // Fast stream copy first (source already web-optimized h264). If the result
  // stays small, keep it (zero quality loss, instant). Otherwise re-encode.
  try {
    await ffmpeg.exec(
      ["-hide_banner", "-loglevel", "error", "-i", "input.bin", "-map", "0:v:0", "-map", "0:a?",
        "-c:v", "copy", "-c:a", "copy", "-movflags", "faststart", "-y", "out.mp4"],
      180000,
    );
    const data = await ffmpeg.readFile("out.mp4");
    const srcData = await ffmpeg.readFile("input.bin");
    if (data.length > 0 && data.length <= srcData.length * 1.02) {
      onProgress(100, "Video ready (stream copied, no quality loss)");
      return new Blob([data], { type: "video/mp4" });
    }
  } catch {
    /* fall through to re-encode */
  }

  onProgress(2, "Encoding optimized video… (this can take a while)");
  let lastP = 0;
  const onVideoProgress = ({ progress: p }: { progress: number }) => {
    if (Number.isFinite(p) && p > lastP) {
      lastP = p;
      onProgress(2 + p * 98, "Encoding optimized video…");
    }
  };
  ffmpeg.on("progress", onVideoProgress);
  try {
    await ffmpeg.exec(
      ["-hide_banner", "-loglevel", "error", "-i", "input.bin", "-map", "0:v:0", "-map", "0:a?",
        "-vf", `scale=${w}:${h}:flags=lanczos,fps=30`, "-c:v", "libx264", "-preset", "ultrafast",
        "-crf", String(crf), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k",
        "-movflags", "faststart", "-y", "out2.mp4"],
      900000,
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new ProcessingError(`Video encoding failed. ${msg}`);
  }
  ffmpeg.off("progress", onVideoProgress);
  const data = await ffmpeg.readFile("out2.mp4");
  return new Blob([data], { type: "video/mp4" });
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
