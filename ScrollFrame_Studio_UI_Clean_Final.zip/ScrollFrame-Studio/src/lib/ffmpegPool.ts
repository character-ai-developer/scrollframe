/**
 * Lazy singleton FFmpeg WASM instance.
 *
 * The core is bundled with the app (see vite.config.ts assetsInclude) so it
 * works on any static host with COOP/COEP. When those headers are absent
 * (e.g. `vite preview`), we fall back to a pinned immutable copy on unpkg —
 * only the ffmpeg *code* is fetched from the network, never user video data.
 */
import { FFmpeg } from "@ffmpeg/ffmpeg";
import { fetchFile } from "@ffmpeg/util";

let instance: FFmpeg | null = null;
let loading: Promise<FFmpeg> | null = null;
let loadError: string | null = null;

declare global {
  interface Window {
    __FFMPEG_CORE_LOADER__?: {
      resolve: () => Promise<string>;
      cdnUrl: string;
    };
  }
}

async function resolveCoreUrl(): Promise<string> {
  const loader = window.__FFMPEG_CORE_LOADER__;
  if (loader) {
    try {
      return await loader.resolve();
    } catch {
      /* fall through to defaults */
    }
  }
  return `${window.location.origin}/ffmpeg-core.js`;
}

export function supportsWasmThreads(): boolean {
  try {
    return typeof SharedArrayBuffer !== "undefined";
  } catch {
    return false;
  }
}

export function hasCrossOriginIsolation(): boolean {
  return typeof window !== "undefined" && window.crossOriginIsolated === true;
}

export async function loadFFmpeg(): Promise<FFmpeg> {
  if (instance) return instance;
  if (loading) return loading;

  loading = (async () => {
    const ffmpeg = new FFmpeg();
    const coreUrl = await resolveCoreUrl();
    try {
      await ffmpeg.load({
        coreURL: coreUrl,
        wasmURL: coreUrl.replace(/\.js$/, ".wasm"),
      });
      instance = ffmpeg;
      loadError = null;
      return ffmpeg;
    } catch (err) {
      loadError = err instanceof Error ? err.message : String(err);
      loading = null;
      // Second attempt: CDN directly (covers stale cache / misconfigured copy)
      if (coreUrl !== window.__FFMPEG_CORE_LOADER__?.cdnUrl) {
        const cdn = window.__FFMPEG_CORE_LOADER__?.cdnUrl;
        if (cdn) {
          await ffmpeg.load({ coreURL: cdn, wasmURL: cdn.replace(/\.js$/, ".wasm") });
          instance = ffmpeg;
          loadError = null;
          return ffmpeg;
        }
      }
      throw err;
    }
  })();

  return loading;
}

export function ffmpegLoadError(): string | null {
  return loadError;
}

export function isFFmpegLoaded(): boolean {
  return instance !== null;
}

export { fetchFile };
