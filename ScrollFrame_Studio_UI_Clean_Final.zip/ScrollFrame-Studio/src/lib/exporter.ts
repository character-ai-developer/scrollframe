import JSZip from "jszip";
import type { ProjectRecord } from "../types";
import { generateSite } from "./site/generator";

export interface ExportProgress {
  percent: number; // 0..100
  stage: string;
  bytesDone: number;
  bytesTotal: number;
}

async function toUint8(blob: Blob): Promise<Uint8Array> {
  return new Uint8Array(await blob.arrayBuffer());
}

/**
 * Package the generated website into a ready-to-deploy ZIP.
 * Progress is real: it tracks actual bytes written into the archive.
 */
export async function exportProjectAsZip(
  project: ProjectRecord,
  onProgress: (p: ExportProgress) => void,
): Promise<Blob> {
  const { result, processingSettings: processing, siteSettings, videoMeta } = project;

  onProgress({ percent: 2, stage: "Generating website files…", bytesDone: 0, bytesTotal: 0 });

  // Resolve blobs → bytes
  const posterBytes = await toUint8(result.posterBlob);
  let frameBytes: Uint8Array[] = [];

  if (result.mode === "frames") {
    if (!result.frames || result.frames.blobs.length === 0) {
      throw new Error("Frame data is missing — please re-process the video.");
    }
    onProgress({ percent: 12, stage: "Reading frames…", bytesDone: 0, bytesTotal: 0 });
    frameBytes = [];
    const total = result.frames.blobs.length;
    for (let i = 0; i < total; i++) {
      frameBytes.push(await toUint8(result.frames.blobs[i]));
      if (total <= 300 || i % 10 === 0 || i === total - 1) {
        onProgress({
          percent: 12 + (i / total) * 18,
          stage: `Reading frames — ${Math.min(i + 1, total)}/${total}`,
          bytesDone: 0,
          bytesTotal: 0,
        });
      }
    }
  }

  let videoBytes: Uint8Array | null = null;
  if (result.mode === "video") {
    if (!result.videoBlob) throw new Error("Video data is missing — please re-process the video.");
    onProgress({ percent: 12, stage: "Reading optimized video…", bytesDone: 0, bytesTotal: 0 });
    videoBytes = await toUint8(result.videoBlob);
  }

  let generated;
  try {
    generated = generateSite({
      site: siteSettings,
      processing,
      videoMeta,
      frameCount: result.count,
      outputWidth: result.width,
      outputHeight: result.height,
      posterBytes,
      frameBytes,
      videoBytesForVideoMode: videoBytes,
    });
  } catch (err) {
    // validation failures must reach the user as a clear export error
    throw new Error(`Export validation failed: ${err instanceof Error ? err.message : String(err)}`);
  }

  // ------------------------------------------------------------- zip
  const zip = new JSZip();
  let bytesDone = 0;
  let bytesTotal = generated.totalBytes;

  onProgress({ percent: 34, stage: "Creating ZIP archive…", bytesDone: 0, bytesTotal });

  const names = Object.keys(generated.files).sort();
  for (const name of names) {
    const v = generated.files[name];
    const isText = typeof v === "string";
    zip.file(name, v as Blob | string, {
      compression: isText ? "DEFLATE" : "STORE",
      compressionOptions: isText ? { level: 6 } : undefined,
    });
    bytesDone += isText ? new Blob([v as string]).size : (v as Uint8Array).byteLength;
    onProgress({
      percent: 34 + (bytesDone / Math.max(1, bytesTotal)) * 46,
      stage: `Creating ZIP archive — ${name}`,
      bytesDone,
      bytesTotal,
    });
  }

  const blob = await zip.generateAsync(
    { type: "blob", streamFiles: true },
    (meta) => {
      onProgress({
        percent: 80 + meta.percent * 0.2,
        stage: "Compressing ZIP…",
        bytesDone: Math.round((meta.percent / 100) * bytesTotal),
        bytesTotal,
      });
    },
  );

  onProgress({ percent: 100, stage: "ZIP ready", bytesDone: blob.size, bytesTotal: blob.size });
  return blob;
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
