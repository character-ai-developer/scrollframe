import type { ProjectRecord } from "../types";
import { assembleHtml } from "./site/generator";

export interface PreviewHandle {
  url: string;
  revoke: () => void;
}

/**
 * Build a live preview of the generated website.
 *
 * The preview reuses the EXACT same HTML/CSS/JS the export produces — only the
 * asset paths are swapped for in-memory blob URLs — so what you scroll in the
 * preview is what you get in the ZIP. Assets are not duplicated; the preview
 * references the project's existing blobs.
 */
export function buildPreviewUrl(project: ProjectRecord): PreviewHandle {
  const { result, siteSettings: site, processingSettings: processing, videoMeta } = project;
  const urls: string[] = [];

  const makeUrl = (blob: Blob): string => {
    const u = URL.createObjectURL(blob);
    urls.push(u);
    return u;
  };

  const posterUrl = makeUrl(result.posterBlob);

  const override: Record<string, unknown> = {
    poster: posterUrl,
  };

  if (result.mode === "frames" && result.frames) {
    // The preview uses the EXACT same runtime as the export; only the asset
    // paths are swapped for in-memory blob URLs (one per frame).
    override.frames = result.frames.blobs.map((b) => makeUrl(b));
  } else if (result.mode === "video" && result.videoBlob) {
    override.videoSrc = makeUrl(result.videoBlob);
  }

  const html = assembleHtml(
    {
      site,
      processing,
      videoMeta,
      frameCount: result.count,
      outputWidth: result.width,
      outputHeight: result.height,
      posterBytes: new Uint8Array(0),
      frameBytes: [],
      videoBytesForVideoMode: null,
    },
    { inlineCss: true, inlineJs: true, configOverride: override },
  );

  const docUrl = URL.createObjectURL(new Blob([html], { type: "text/html" }));
  urls.push(docUrl);

  return {
    url: docUrl,
    revoke: () => urls.forEach((u) => URL.revokeObjectURL(u)),
  };
}
