import type { ProcessingSettings, SiteSettings, VideoMeta } from "../../types";
import { formatBytes } from "../../types";
import indexTemplate from "./index-template.html?raw";
import cssTemplate from "./template.css?raw";
import runtimeJs from "./runtime.js?raw";

export interface GeneratedSiteInput {
  site: SiteSettings;
  processing: ProcessingSettings;
  videoMeta: VideoMeta;
  frameCount: number;
  outputWidth: number;
  outputHeight: number;
  posterBytes: Uint8Array;
  frameBytes: Uint8Array[]; // one optimized image per frame, playback order (frames mode)
  videoBytesForVideoMode: Uint8Array | null;
}

export interface GeneratedSite {
  files: Record<string, string | Uint8Array>;
  totalBytes: number;
}

const FONT_LINKS: Record<string, string> = {
  inter:
    '<link rel="preconnect" href="https://fonts.googleapis.com" />\n    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />',
  system: "",
  serif: '<link rel="preconnect" href="https://fonts.googleapis.com" />\n    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n    <link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap" rel="stylesheet" />',
};

const FONT_STACKS: Record<string, string> = {
  inter: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
  system:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
  serif: "'Source Serif 4', Georgia, 'Times New Roman', serif",
};

export function travelVhFor(site: SiteSettings): number {
  // Give the scroll substantially more physical distance so a single
  // wheel/trackpad impulse advances only a small number of frames.
  // The previous 90vh/sec mapping was still too dense for typical 100–120px
  // wheel deltas. Increasing the travel distance does not add rendering work;
  // it simply gives the user finer physical control over the same frame range.
  // 180vh/sec is the new baseline and keeps the generator's animationDuration
  // meaning intact while making frame progression noticeably smoother.
  return Math.max(300, Math.round(site.animationDuration * site.scrollSensitivity * 300));
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(full, 16);
  if (Number.isNaN(n)) return { r: 9, g: 9, b: 11 };
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgba(hex: string, alpha: number): string {
  const { r, g, b } = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function buildCssVars(site: SiteSettings): string {
  const bg =
    site.backgroundStyle === "solid"
      ? site.backgroundColor
      : site.backgroundStyle === "dark-overlay"
        ? "linear-gradient(180deg, #f4f4f5 0%, #e8e8ea 100%)"
        : `linear-gradient(160deg, ${site.backgroundGradientFrom} 0%, ${site.backgroundGradientTo} 100%)`;

  const stage =
    site.backgroundStyle === "dark-overlay"
      ? `linear-gradient(rgba(8,8,10,0.28), rgba(8,8,10,0.55)), ${site.backgroundColor}`
      : site.backgroundStyle === "solid"
        ? site.backgroundColor
        : `linear-gradient(160deg, ${site.backgroundGradientFrom} 0%, ${site.backgroundGradientTo} 100%)`;

  return [
    `  --sfs-bg: ${bg};`,
    `  --sfs-stage: ${stage};`,
    `  --sfs-text: ${site.textColor};`,
    `  --sfs-accent: ${site.accentColor};`,
    `  --sfs-font: ${FONT_STACKS[site.fontFamily] || FONT_STACKS.inter};`,
    `  --sfs-travel: ${travelVhFor(site)}vh;`,
    `  --sfs-overlay: ${rgba(site.textColor, 0.08)};`,
  ].join("\n");
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function stripBlock(html: string, name: string, keep: boolean): string {
  const start = `<!-- SFS:${name} -->`;
  const end = `<!-- /SFS:${name} -->`;
  const i = html.indexOf(start);
  const j = html.indexOf(end);
  if (i === -1 || j === -1) return html;
  if (keep) return html;
  return html.slice(0, i) + html.slice(j + end.length);
}

function stripButtons(html: string, showPlay: boolean, showFullscreen: boolean, showSound: boolean): string {
  const btnPlay = html.match(/<button id="sfs-btn-play"[\s\S]*?<\/button>/);
  const btnFull = html.match(/<button id="sfs-btn-fullscreen"[\s\S]*?<\/button>/);
  const btnSound = html.match(/<button id="sfs-btn-sound"[\s\S]*?<\/button>/);
  let out = html;
  if (!showPlay && btnPlay) out = out.replace(btnPlay[0], "");
  if (!showFullscreen && btnFull) out = out.replace(btnFull[0], "");
  if (!showSound && btnSound) out = out.replace(btnSound[0], "");
  return out;
}

function buildRuntimeConfig(
  input: GeneratedSiteInput,
): Record<string, unknown> {
  const { site, processing, videoMeta } = input;
  const mode = processing.mode;
  return {
    title: siteTitle(input),
    mode,
    frameCount: input.frameCount,
    fps: processing.fps,
    width: input.outputWidth,
    height: input.outputHeight,
    duration: videoMeta.duration,
    poster: "assets/poster." + extFor(processing.imageFormat),
    videoSrc: mode === "video" ? "assets/video." + videoExt(videoMeta.mimeType) : null,
    framesPrefix: "assets/frames/frame_",
    framePad: 5,
    framesSuffix: "." + processing.imageFormat,
    travelVh: travelVhFor(site),
    startOffsetVh: site.startOffset,
    endOffsetVh: site.endOffset,
    easing: site.easing,
    smoothing: site.smoothing,
    reverseOnScrollUp: site.reverseOnScrollUp,
    fitMode: site.fitMode,
    showLoadingScreen: site.showLoadingScreen,
    showScrollIndicator: site.showScrollIndicator,
    showProgress: site.showProgress,
    showPlayPause: site.showPlayPause,
    showFullscreen: site.showFullscreen,
    showSound: site.showSound,
  };
}

function extFor(format: ProcessingSettings["imageFormat"]): string {
  return format === "jpeg" ? "jpg" : format;
}

/** Deterministic asset path for frame i (0-based) inside the exported site. */
export function frameAssetPath(i: number, format: ProcessingSettings["imageFormat"]): string {
  return `assets/frames/frame_${String(i + 1).padStart(5, "0")}.${extFor(format)}`;
}

function videoExt(mime: string): string {
  if (mime.includes("webm")) return "webm";
  if (mime.includes("quicktime")) return "mov";
  return "mp4";
}

export function siteTitle(input: GeneratedSiteInput): string {
  const base = input.videoMeta.filename.replace(/\.[^.]+$/, "");
  return base.replace(/[-_]+/g, " ").slice(0, 48) || "Scroll Experience";
}

export interface AssembleOptions {
  inlineCss?: boolean;
  inlineJs?: boolean;
  configOverride?: Record<string, unknown>;
}

/**
 * Build the final index.html. With inlineCss/inlineJs the result is a single
 * self-contained document (used for the in-app live preview); otherwise it
 * references style.css / script.js (used for the exported project).
 */
export function assembleHtml(input: GeneratedSiteInput, opts: AssembleOptions = {}): string {
  const { site } = input;
  let html = indexTemplate;
  html = html.replace("__SFS_TITLE__", escapeHtml(siteTitle(input)));
  html = html.replace("__SFS_FONT_LINK__", FONT_LINKS[site.fontFamily] || "");
  html = html.replace("__SFS_INTRO__", escapeHtml(site.introText || siteTitle(input)));
  // Warm the browser cache before the runtime starts its JS loader. Only a
  // small leading window is preloaded so we do not flood the network.
  if (input.processing.mode === "frames" && input.frameCount > 0) {
    const preloadCount = Math.min(16, input.frameCount);
    const preloadLinks = Array.from({ length: preloadCount }, (_, i) =>
      `<link rel="preload" as="image" href="${frameAssetPath(i, input.processing.imageFormat)}" fetchpriority="high" />`,
    ).join("\n    ");
    html = html.replace("</head>", `${preloadLinks}\n  </head>`);
  }
  html = html.replace("__SFS_OUTRO__", escapeHtml(site.outroText || ""));
  html = stripBlock(html, "loading", site.showLoadingScreen);
  html = stripBlock(html, "progress", site.showProgress);
  html = stripBlock(html, "intro", site.introText.trim().length > 0);
  html = stripBlock(html, "hint", site.showScrollIndicator);
  html = stripBlock(html, "outro", site.outroText.trim().length > 0);
  html = stripButtons(html, site.showPlayPause, site.showFullscreen, site.showSound);

  const css = cssTemplate.replace("  /* __SFS_CSS_VARS__ */", buildCssVars(site));
  const config = { ...buildRuntimeConfig(input), ...(opts.configOverride || {}) };
  const js = runtimeJs.replace("__SFS_JSON__", JSON.stringify(config));

  if (opts.inlineCss) {
    html = html.replace('<link rel="stylesheet" href="style.css" />', `<style>\n${css}\n</style>`);
  }
  if (opts.inlineJs) {
    html = html.replace('<script src="script.js"></script>', `<script>\n${js}\n</script>`);
  }
  return html;
}

export function buildCss(input: GeneratedSiteInput): string {
  return cssTemplate.replace("  /* __SFS_CSS_VARS__ */", buildCssVars(input.site));
}

export function buildJs(input: GeneratedSiteInput, configOverride?: Record<string, unknown>): string {
  const config = { ...buildRuntimeConfig(input), ...(configOverride || {}) };
  return runtimeJs.replace("__SFS_JSON__", JSON.stringify(config));
}

/** Assemble the full standalone website. */
export function generateSite(input: GeneratedSiteInput): GeneratedSite {
  const { site, processing, videoMeta } = input;

  const files: Record<string, string | Uint8Array> = {
    "index.html": assembleHtml(input),
    "style.css": buildCss(input),
    "script.js": buildJs(input),
    "README.md": buildReadme(input),
    ["assets/poster." + extFor(processing.imageFormat)]: input.posterBytes,
  };

  if (processing.mode === "video" && input.videoBytesForVideoMode) {
    files["assets/video." + videoExt(videoMeta.mimeType)] = input.videoBytesForVideoMode;
  }

  // individual frames: one optimized image per video frame
  if (processing.mode === "frames") {
    input.frameBytes.forEach((bytes, i) => {
      files[frameAssetPath(i, processing.imageFormat)] = bytes;
    });
  }

  validateGeneratedSite(input);

  let totalBytes = 0;
  for (const k of Object.keys(files)) {
    const v = files[k];
    totalBytes += typeof v === "string" ? new Blob([v]).size : v.byteLength;
  }

  return { files, totalBytes };
}

/**
 * Pre-export validation pass: every generated website must not contain known
 * runtime errors (undefined variables, broken frame paths, missing frames,
 * NaN/out-of-range indexes, invalid script syntax). Throws with a descriptive
 * message listing every problem found.
 */
export function validateGeneratedSite(input: GeneratedSiteInput): void {
  const problems: string[] = [];

  // canonical frame count: must be a finite integer > 0
  const fc = input.frameCount;
  if (!Number.isFinite(fc) || fc <= 0 || Math.floor(fc) !== fc) {
    problems.push(`frameCount is invalid: ${String(fc)}`);
  }

  // poster must exist
  if (input.posterBytes.byteLength === 0) {
    problems.push("poster asset is empty");
  }

  // frames mode: every frame present, non-empty, deterministic path, in range
  if (input.processing.mode === "frames") {
    if (!Array.isArray(input.frameBytes)) {
      problems.push("frameBytes is missing");
    } else if (fc > 0) {
      if (input.frameBytes.length !== fc) {
        problems.push(`frameBytes.length (${input.frameBytes.length}) !== frameCount (${fc})`);
      }
      const seen = new Set<string>();
      for (let i = 0; i < input.frameBytes.length; i++) {
        const p = frameAssetPath(i, input.processing.imageFormat);
        if (seen.has(p)) problems.push(`duplicate frame path: ${p}`);
        seen.add(p);
        if (input.frameBytes[i].byteLength === 0) {
          problems.push(`frame ${i + 1} (${p}) is empty`);
        }
      }
    }
  }

  // runtime script must be syntactically valid
  try {
    const js = buildJs(input);
    // eslint-disable-next-line no-new-func
    new Function(js);
  } catch (err) {
    problems.push(`generated script.js is not valid JavaScript: ${err instanceof Error ? err.message : String(err)}`);
  }

  // config must round-trip through JSON with no NaN / undefined leaks
  const config = buildRuntimeConfig(input);
  const json = JSON.stringify(config);
  if (json === undefined || json.includes("NaN") || json.includes("undefined")) {
    problems.push("runtime config contains non-serializable values");
  }
  try {
    JSON.parse(json);
  } catch (err) {
    problems.push(`runtime config is not valid JSON: ${err instanceof Error ? err.message : String(err)}`);
  }

  if (problems.length > 0) {
    throw new Error(`Generated website failed validation:\n - ${problems.join("\n - ")}`);
  }
}

function buildReadme(input: GeneratedSiteInput): string {
  const { site, processing, videoMeta } = input;
  const travel = travelVhFor(site);
  const formatLabel = processing.imageFormat === "webp" ? "WebP" : processing.imageFormat === "jpeg" ? "JPEG" : "PNG";
  const exportBytes =
    input.posterBytes.byteLength +
    input.frameBytes.reduce((a, b) => a + b.byteLength, 0) +
    (input.videoBytesForVideoMode?.byteLength ?? 0) +
    64 * 1024;
  const modeLine =
    processing.mode === "video"
      ? "The site embeds the original video and maps scroll position to `video.currentTime` (Video Mode)."
      : "The site uses pre-extracted, optimized frames drawn to a `<canvas>` (Frame Mode).";

  return `# ${siteTitle(input)}

A scroll-controlled video experience generated with **ScrollFrame Studio**.

Scrolling down plays the video forward; scrolling up plays it backward.
The animation stays pinned to the viewport while the page scrolls.

## Quick start

\`\`\`bash
# Serve this folder with any static server, e.g.:
python3 -m http.server 8080
# or
npx serve .
# then open the printed URL in your browser
\`\`\`

No build step, no dependencies, no API keys. Open \`index.html\` and it works.

## Deploy anywhere

The site is fully static. Upload this folder to any static host:

- **GitHub Pages** — push the folder to a repo, enable Pages
- **Netlify** — drag & drop the folder at app.netlify.com/drop
- **Vercel** — \`vercel deploy\`
- **Cloudflare Pages** — upload via the dashboard

## How the scroll animation works

- \`index.html\` contains a pinned section (\`#sfs-anim\` → \`#sfs-pin\`, \`position: sticky; height: 100vh\`).
- \`script.js\` maps \`window.scrollY\` inside that section to a 0→1 progress value,
  applies easing/smoothing, then draws the matching frame on a full-viewport canvas.
- Scrolling up simply moves the progress backwards — no video element is playing
  (Frame Mode), so reversing is instant and frame-perfect.

## Where the frames live

- \`assets/frames/frame_00001.${processing.imageFormat}\` … \`frame_${String(input.frameCount).padStart(5, "0")}.${processing.imageFormat}\`
  — the individual optimized frames, one image per video frame
  (${input.frameCount} frames at ${processing.fps} FPS, ${input.outputWidth}×${input.outputHeight}px, ${formatLabel}).
- \`assets/poster.${extFor(processing.imageFormat)}\` — first frame, shown instantly.

The runtime loads frames on demand with a priority loader (current frame first,
then the scroll direction), keeps a bounded decoded cache, and always keeps the
last valid frame on screen when the requested frame is not ready yet.

${modeLine}

## Customize colors

Open \`style.css\` and edit the variables at the top:

\`\`\`css
:root {
  --sfs-bg: ...;      /* page background */
  --sfs-stage: ...;   /* area behind the canvas */
  --sfs-text: ...;    /* text color */
  --sfs-accent: ...;  /* accent (progress bar, hints) */
}
\`\`\`

## Change animation settings

Open \`script.js\` and edit the \`CONFIG\` object at the top:

| Key | Effect |
| --- | --- |
| \`travelVh\` | How tall the scroll section is, in viewport heights (${travel}vh here) |
| \`startOffsetVh\` / \`endOffsetVh\` | Extra space before/after the animation |
| \`easing\` | \`linear\`, \`smoothstep\`, \`ease-in-out\` |
| \`smoothing\` | 0 (instant) → 1 (very smooth/floaty) |
| \`reverseOnScrollUp\` | \`false\` locks progress to the furthest point reached |
| \`fitMode\` | \`cover\` (fill, crop) or \`contain\` (letterbox) |
| \`frameCount\` / \`fps\` | Frame count and effective playback rate |

## Regenerate

Re-upload the source video to ScrollFrame Studio and export again — every
setting is remembered per project.

---

*Source video: ${videoMeta.filename} · ${formatBytes(videoMeta.fileSize)} ·
${videoMeta.duration.toFixed(1)}s · ${videoMeta.width}×${videoMeta.height}@${videoMeta.fps.toFixed(1)}fps ·
Frames: ${input.frameCount} · Export: ${formatBytes(exportBytes)}*
`;
}
