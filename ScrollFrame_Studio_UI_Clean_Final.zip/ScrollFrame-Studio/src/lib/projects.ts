import type { ProjectRecord } from "../types";

/**
 * Local project persistence via IndexedDB.
 *
 * Everything (video-derived data, frames, sprites, settings) stays in the
 * browser. Projects are stored locally so the dashboard can show "Recent
 * Projects". If storage quota is exceeded, the project's heavy blobs are
 * dropped but the card remains visible.
 */

const DB_NAME = "scrollframe-studio";
const DB_VERSION = 1;
const STORE = "projects";

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is not available in this browser."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("Could not open local database."));
  });
  return dbPromise;
}

function tx<T>(mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(STORE, mode);
        const req = fn(t.objectStore(STORE));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error || new Error("Database error."));
      }),
  );
}

export async function listProjects(): Promise<ProjectRecord[]> {
  try {
    const all = await tx<ProjectRecord[]>("readonly", (s) => s.getAll() as IDBRequest<ProjectRecord[]>);
    return (all || []).sort((a, b) => b.updatedAt - a.updatedAt);
  } catch {
    return [];
  }
}

export async function getProject(id: string): Promise<ProjectRecord | null> {
  try {
    return (await tx<ProjectRecord | undefined>("readonly", (s) => s.get(id))) ?? null;
  } catch {
    return null;
  }
}

export async function saveProject(project: ProjectRecord): Promise<boolean> {
  try {
    await tx("readwrite", (s) => s.put(project));
    return true;
  } catch (err) {
    // Quota exceeded (or blocked): retry with blobs stripped so the dashboard
    // still lists the project, but mark it degraded.
    if (err instanceof DOMException && (err.name === "QuotaExceededError" || err.name === "AbortError")) {
      try {
        const stripped: ProjectRecord = {
          ...project,
          result: { ...project.result, framesBlob: null, posterBlob: new Blob(), frames: null, videoBlob: null },
        };
        await tx("readwrite", (s) => s.put(stripped));
        return false;
      } catch {
        return false;
      }
    }
    return false;
  }
}

export async function deleteProject(id: string): Promise<void> {
  try {
    await tx("readwrite", (s) => s.delete(id));
  } catch {
    /* ignore */
  }
}

export async function clearProjects(): Promise<void> {
  try {
    await tx("readwrite", (s) => s.clear());
  } catch {
    /* ignore */
  }
}

/** Total size of blobs stored for this project (for the dashboard). */
export function projectSize(project: ProjectRecord): number {
  let bytes = 0;
  const b = project.result;
  if (b.posterBlob) bytes += b.posterBlob.size;
  if (b.framesBlob) bytes += b.framesBlob.size;
  if (b.videoBlob) bytes += b.videoBlob.size;
  if (b.frames) bytes += b.frames.blobs.reduce((s, x) => s + x.size, 0);
  return bytes;
}
