import { ArrowUpRight, Clock, FileVideo2, Layers, Plus, Trash2, Film, Zap, ShieldCheck } from "lucide-react";
import { useStudioStore } from "../store/useStudioStore";
import { formatBytes, formatDuration } from "../types";
import { projectSize } from "../lib/projects";

const TICKER = [
  "100% LOCAL PROCESSING",
  "NO UPLOADS",
  "FFMPEG WASM IN-BROWSER",
  "FRAME-PERFECT SCRUB",
  "EXPORT A STANDALONE WEBSITE",
  "NO BACKEND · NO API KEYS",
  "SCROLL FORWARD · SCROLL BACK",
];

export default function Dashboard() {
  const setView = useStudioStore((s) => s.setView);
  const projects = useStudioStore((s) => s.projects);
  const selectProject = useStudioStore((s) => s.selectProject);
  const deleteProject = useStudioStore((s) => s.deleteProject);
  const processingActive = useStudioStore((s) => s.processing.active);

  return (
    <div className="h-full overflow-y-auto bg-paper">
      {/* marquee ticker */}
      <div className="sf-marquee border-b-[3px] border-ink bg-ink py-2 text-paper">
        {[0, 1].map((copy) => (
          <div key={copy} className="sf-marquee-track" aria-hidden={copy === 1}>
            {TICKER.map((t) => (
              <span key={t} className="mx-6 flex items-center gap-6 font-mono text-[10.5px] font-bold tracking-[0.18em] uppercase">
                {t} <span className="text-accent">◆</span>
              </span>
            ))}
          </div>
        ))}
      </div>

      {/* hero */}
      <div className="sf-grid-bg relative border-b-[3px] border-ink">
        <div className="relative mx-auto max-w-5xl px-6 py-12 md:px-10 md:py-16">
          <div className="sf-pop flex items-center gap-2 font-mono text-[11px] font-black tracking-[0.2em] text-ink/70 uppercase">
            <Zap className="h-3.5 w-3.5 text-accent" /> Video → Scroll Website Generator
          </div>
          <h1 className="sf-pop mt-5 max-w-3xl font-display text-4xl font-black uppercase leading-[0.95] tracking-tight text-ink [animation-delay:60ms] md:text-6xl">
            Turn any video into a{" "}
            <span className="relative inline-block">
              scroll
              <span className="absolute -bottom-1 left-0 h-2.5 w-full bg-accent" />
            </span>{" "}
            experience
          </h1>
          <p className="sf-pop mt-6 max-w-xl text-[15px] leading-relaxed text-ink/70 [animation-delay:120ms]">
            Upload a video. The studio extracts optimized frames, pins them to the page, and lets
            scrolling control the playback — forward and backward. Export a standalone website in one
            click.
          </p>

          <div className="sf-pop mt-8 flex flex-wrap items-center gap-3 [animation-delay:180ms]">
            <button
              onClick={() => setView("upload")}
              disabled={processingActive}
              className="sf-btn sf-btn-accent px-7 py-3.5 text-[13px]"
            >
              <Plus className="h-4 w-4" /> New Project
            </button>
            <span className="sf-chip">
              <ShieldCheck className="h-3.5 w-3.5 text-ok" />
              Local-only · no uploads · no account
            </span>
          </div>

          {/* steps */}
          <div className="sf-pop mt-10 grid grid-cols-1 gap-3 sm:grid-cols-3 [animation-delay:240ms]">
            {[
              ["01", "UPLOAD", "MP4 · WebM · MOV"],
              ["02", "PROCESS", "Frames extracted in-browser"],
              ["03", "EXPORT", "Standalone website ZIP"],
            ].map(([num, title, sub]) => (
              <div key={num} className="sf-card flex items-center gap-3 px-4 py-3">
                <span className="font-mono text-xl font-black text-accent">{num}</span>
                <div>
                  <div className="text-[13px] font-black uppercase tracking-wide">{title}</div>
                  <div className="font-mono text-[10.5px] text-ink/55">{sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* recent projects */}
      <div className="mx-auto max-w-5xl px-6 py-10 md:px-10">
        <div className="mb-5 flex items-center justify-between border-b-[3px] border-ink pb-3">
          <h2 className="font-display text-xl font-black uppercase tracking-tight">Recent projects</h2>
          <span className="font-mono text-[11px] font-bold text-ink/50">
            [{projects.length}] stored locally
          </span>
        </div>

        {projects.length === 0 ? (
          <div className="sf-card-flat mt-6 px-8 py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center border-2 border-ink bg-accent shadow-[4px_4px_0_0_#161616]">
              <FileVideo2 className="h-7 w-7 text-ink" />
            </div>
            <h3 className="mt-5 font-display text-lg font-black uppercase">No projects yet</h3>
            <p className="mx-auto mt-2 max-w-sm text-[13px] leading-relaxed text-ink/60">
              Upload an MP4, WebM or MOV and the studio will build a scroll-controlled website from
              its frames — preview, customize, and export it as a ZIP.
            </p>
            <button
              onClick={() => setView("upload")}
              disabled={processingActive}
              className="sf-btn mt-6"
            >
              <Plus className="h-4 w-4" /> Upload your first video
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((p, i) => (
              <div
                key={p.id}
                className="sf-pop group relative sf-card transition-transform hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[2px_2px_0_0_#161616]"
                style={{ animationDelay: `${i * 50}ms` }}
              >
                <button className="block w-full text-left" onClick={() => selectProject(p.id)}>
                  {/* poster */}
                  <div className="relative h-36 overflow-hidden border-b-2 border-ink bg-ink">
                    {p.result.posterBlob.size > 0 ? (
                      <img
                        src={URL.createObjectURL(p.result.posterBlob)}
                        alt=""
                        className="h-full w-full object-cover"
                        onLoad={(e) => {
                          const img = e.currentTarget;
                          const src = img.src;
                          requestAnimationFrame(() => URL.revokeObjectURL(src));
                        }}
                      />
                    ) : (
                      <div className="grid h-full w-full place-items-center bg-ink">
                        <Film className="h-8 w-8 text-paper/40" />
                      </div>
                    )}
                    <div className="absolute left-2 top-2">
                      <span className="sf-chip bg-paper text-ink">
                        {p.result.mode === "video" ? (
                          <Film className="h-3 w-3 text-accent" />
                        ) : (
                          <Layers className="h-3 w-3 text-accent" />
                        )}
                        {p.result.mode === "video" ? "Video mode" : "Frame mode"}
                      </span>
                    </div>
                    <div className="absolute bottom-2 left-2 flex items-center gap-1.5">
                      <span className="sf-chip bg-ink text-paper">
                        <Clock className="h-3 w-3 text-accent" /> {formatDuration(p.videoMeta.duration)}
                      </span>
                      <span className="sf-chip bg-ink text-paper">{p.videoMeta.width}×{p.videoMeta.height}</span>
                    </div>
                  </div>
                  <div className="px-4 py-3">
                    <div className="truncate text-[13.5px] font-black uppercase tracking-wide">{p.name}</div>
                    <div className="mt-1.5 flex items-center justify-between font-mono text-[10.5px] text-ink/55">
                      <span>
                        {p.result.count} frames · {formatBytes(projectSize(p))}
                      </span>
                      <span>{formatBytes(p.videoMeta.fileSize)} src</span>
                    </div>
                  </div>
                </button>
                <button
                  onClick={() => void deleteProject(p.id)}
                  className="absolute right-2.5 bottom-2.5 grid h-8 w-8 place-items-center border-2 border-ink bg-paper text-ink opacity-0 transition-all hover:bg-danger hover:text-paper group-hover:opacity-100"
                  title="Delete project"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}

            {/* new project tile */}
            <button
              onClick={() => setView("upload")}
              disabled={processingActive}
              className="group grid min-h-[228px] place-items-center border-[3px] border-dashed border-ink/50 bg-transparent transition-all hover:border-ink hover:bg-accent/10 disabled:opacity-50"
            >
              <div className="text-center">
                <div className="mx-auto grid h-14 w-14 place-items-center border-2 border-ink bg-paper shadow-[4px_4px_0_0_#161616] transition-all group-hover:bg-accent">
                  <Plus className="h-7 w-7 text-ink" />
                </div>
                <div className="mt-4 font-display text-sm font-black uppercase tracking-wide">
                  New project
                </div>
                <div className="mt-1 flex items-center justify-center gap-1 font-mono text-[11px] text-ink/55">
                  Upload a video <ArrowUpRight className="h-3 w-3" />
                </div>
              </div>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
