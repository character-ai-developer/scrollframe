import { useState } from "react";
import { Info, X } from "lucide-react";
import { useStudioStore } from "../store/useStudioStore";

export default function SettingsModal() {
  const open = useStudioStore((s) => s.settingsOpen);
  const setOpen = useStudioStore((s) => s.setSettingsOpen);
  const maxFileSizeMB = useStudioStore((s) => s.maxFileSizeMB);
  const setMaxFileSizeMB = useStudioStore((s) => s.setMaxFileSizeMB);
  const [draft, setDraft] = useState<number | null>(null);

  if (!open) return null;
  const value = draft ?? maxFileSizeMB;

  return (
    <div
      className="absolute inset-0 z-50 grid place-items-center bg-ink/60"
      onClick={() => setOpen(false)}
    >
      <div
        className="sf-pop w-full max-w-md sf-card sf-topbar bg-card p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b-[3px] border-ink pb-3">
          <h2 className="font-display text-lg font-black uppercase tracking-wide">Settings</h2>
          <button
            onClick={() => setOpen(false)}
            className="sf-btn sf-btn-square sf-btn-sm"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-5 space-y-5">
          <div>
            <label className="mb-1.5 block text-[12px] font-black uppercase text-ink/75">
              Maximum upload size — <span className="text-accent">{value} MB</span>
            </label>
            <input
              type="range"
              min={50}
              max={4096}
              step={50}
              value={value}
              onChange={(e) => setDraft(+e.target.value)}
              className="sf-range"
            />
            <div className="mt-1 flex justify-between font-mono text-[10px] font-bold text-ink/45">
              <span>50 MB</span>
              <span>4 GB</span>
            </div>
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => {
                  setMaxFileSizeMB(value);
                  setDraft(null);
                  setOpen(false);
                }}
                className="sf-btn sf-btn-accent flex-1"
              >
                Save
              </button>
              <button
                onClick={() => {
                  setDraft(null);
                  setOpen(false);
                }}
                className="sf-btn sf-btn-ghost"
              >
                Cancel
              </button>
            </div>
          </div>

          <div className="flex items-start gap-2.5 border-2 border-ink bg-white px-3.5 py-3">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
            <p className="text-[11.5px] leading-relaxed text-ink/65">
              Larger files take more memory to process in the browser. Videos are read into RAM for
              FFmpeg WASM extraction and are never uploaded anywhere.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
