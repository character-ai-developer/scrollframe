import { useState } from "react";
import { Check, Download, FolderTree, Loader2, Package } from "lucide-react";
import { useStudioStore } from "../store/useStudioStore";
import type { ProjectRecord } from "../types";
import { formatBytes } from "../types";
import { exportProjectAsZip, downloadBlob } from "../lib/exporter";
import { projectSize } from "../lib/projects";

type ExportState =
  | { status: "idle" }
  | { status: "working"; percent: number; stage: string }
  | { status: "done"; bytes: number; filename: string };

export default function ExportPane({ project }: { project: ProjectRecord }) {
  const [state, setState] = useState<ExportState>({ status: "idle" });
  const [error, setError] = useState<string | null>(null);
  const r = project.result;

  const estZip =
    (r.frames ? r.frames.blobs.reduce((s, b) => s + b.size, 0) : 0) +
    (r.videoBlob?.size ?? 0) +
    r.posterBlob.size +
    90 * 1024;

  const doExport = async () => {
    if (state.status === "working") return;
    setError(null);
    setState({ status: "working", percent: 0, stage: "Starting…" });
    try {
      const zip = await exportProjectAsZip(project, (p) => {
        setState({ status: "working", percent: p.percent, stage: p.stage });
      });
      const filename = `${slugify(project.name)}-scroll-website.zip`;
      downloadBlob(zip, filename);
      setState({ status: "done", bytes: zip.size, filename });
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setState({ status: "idle" });
    }
  };

  return (
    <div className="flex h-full flex-col bg-paper">
      <div className="shrink-0 border-b-[3px] border-ink bg-ink px-4 py-3 text-paper">
        <div className="flex items-center gap-2 text-[13px] font-black uppercase tracking-wide">
          <Package className="h-4 w-4 text-accent" />
          Export
        </div>
      </div>

      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto bg-paper p-4">
        {/* summary */}
        <div className="sf-card-flat p-4">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] font-bold tracking-[0.14em] text-ink/50 uppercase">
              Project summary
            </span>
            <span
              className={`sf-chip !py-0.5 text-[9.5px] ${
                r.mode === "frames" ? "bg-accent" : "bg-ink text-paper"
              }`}
            >
              {r.mode === "frames" ? "Frame Mode" : "Video Mode"}
            </span>
          </div>
          <dl className="mt-3 space-y-2 text-[12.5px]">
            <Row k="Frames extracted" v={r.count.toLocaleString()} />
            <Row k="Playback rate" v={`${r.fps} FPS`} />
            <Row k="Frame size" v={`${r.width}×${r.height}px`} />
            <Row k="Format" v={r.format.toUpperCase()} />
            <Row k="Source video" v={formatBytes(r.sourceBytes)} />
            <Row k="Processing time" v={`${(r.timeMs / 1000).toFixed(1)}s`} />
            <Row k="Estimated ZIP" v={formatBytes(estZip)} accent />
          </dl>
        </div>

        {/* export button */}
        <div className="sf-card-flat border-accent/60 p-4">
          <button
            onClick={() => void doExport()}
            disabled={state.status === "working"}
            className="sf-btn sf-btn-accent w-full px-6 py-4 text-[14px]"
          >
            <span className="flex items-center justify-center gap-2.5">
              {state.status === "working" ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  {state.stage}
                </>
              ) : state.status === "done" ? (
                <>
                  <Check className="h-5 w-5" /> Downloaded — export again?
                </>
              ) : (
                <>
                  <Download className="h-5 w-5" />
                  Export Website
                </>
              )}
            </span>
          </button>

          {state.status === "working" && (
            <div className="mt-3">
              <div className="h-4 border-2 border-ink bg-white">
                <div
                  className="h-full bg-accent transition-[width] duration-200"
                  style={{ width: `${Math.max(2, state.percent)}%` }}
                />
              </div>
              <div className="mt-1.5 flex justify-between font-mono text-[10px] font-bold text-ink/60">
                <span>{state.stage}</span>
                <span className="tabular-nums">{Math.round(state.percent)}%</span>
              </div>
            </div>
          )}

          {state.status === "done" && (
            <p className="mt-3 flex items-start gap-2 text-[12px] leading-relaxed text-ink/75">
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ok" />
              <span>
                <span className="font-black">{state.filename}</span> downloaded (
                {formatBytes(state.bytes)}). Unzip it and open{" "}
                <code className="border border-ink/40 bg-white px-1 font-mono text-[10.5px]">index.html</code>.
              </span>
            </p>
          )}

          {error && (
            <p className="mt-3 border-2 border-danger bg-danger/10 px-3 py-2.5 text-[12px] leading-relaxed text-ink">
              {error}
            </p>
          )}
        </div>

        {/* contents */}
        <div className="sf-card-flat p-4">
          <div className="flex items-center gap-2 font-mono text-[10px] font-bold tracking-[0.14em] text-ink/50 uppercase">
            <FolderTree className="h-3.5 w-3.5 text-accent" /> What's inside the ZIP
          </div>
          <div className="mt-3 space-y-1.5 font-mono text-[11.5px] leading-relaxed text-ink/75">
            <div className="font-black">scroll-website/</div>
            <div className="pl-4">├── index.html</div>
            <div className="pl-4">├── style.css</div>
            <div className="pl-4">├── script.js</div>
            <div className="pl-4">├── README.md</div>
            <div className="pl-4">├── assets/</div>
            <div className="pl-8">│   ├── poster.{r.format === "jpeg" ? "jpg" : r.format}</div>
            {r.mode === "frames" ? (
              <>
                <div className="pl-8">│   ├── frames/</div>
                <div className="pl-10">│   │   ├── frame_00001.{r.format}</div>
                <div className="pl-10">│   │   ├── … {r.count.toLocaleString()} frames</div>
                <div className="pl-10">│   │   └── frame_{String(r.count).padStart(5, "0")}.{r.format}</div>
              </>
            ) : (
              <div className="pl-8">│   └── video.mp4</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v, accent }: { k: string; v: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between border-b border-dashed border-ink/20 pb-1.5">
      <dt className="font-mono text-[11px] text-ink/50">{k}</dt>
      <dd className={`font-mono text-[12px] tabular-nums ${accent ? "font-black text-accent" : "font-bold text-ink"}`}>{v}</dd>
    </div>
  );
}

function slugify(s: string): string {
  return (
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "scroll"
  );
}
