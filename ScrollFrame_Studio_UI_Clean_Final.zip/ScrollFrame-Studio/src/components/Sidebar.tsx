import { FolderOpen, Plus, Settings, Video, Film, Layers, Clapperboard } from "lucide-react";
import { useStudioStore } from "../store/useStudioStore";
import { formatBytes } from "../types";
import { projectSize } from "../lib/projects";

const ICON_CLS = "h-4 w-4";

export default function Sidebar() {
  const view = useStudioStore((s) => s.view);
  const setView = useStudioStore((s) => s.setView);
  const projects = useStudioStore((s) => s.projects);
  const activeProjectId = useStudioStore((s) => s.activeProjectId);
  const selectProject = useStudioStore((s) => s.selectProject);
  const setSettingsOpen = useStudioStore((s) => s.setSettingsOpen);

  const items: { id: "dashboard" | "upload"; num: string; label: string; icon: React.ReactNode }[] = [
    { id: "dashboard", num: "01", label: "Projects", icon: <FolderOpen className={ICON_CLS} /> },
    { id: "upload", num: "02", label: "New Project", icon: <Plus className={ICON_CLS} /> },
  ];

  return (
    <aside className="sf-topbar hidden w-[250px] shrink-0 flex-col border-r-[3px] border-ink bg-ink text-paper md:flex">
      {/* logo */}
      <div className="flex items-center gap-3 border-b-2 border-paper/20 px-4 py-5">
        <div className="grid h-10 w-10 shrink-0 place-items-center bg-accent shadow-[3px_3px_0_0_#faf7ef]">
          <Clapperboard className="h-5 w-5 text-ink" />
        </div>
        <div>
          <div className="font-display text-[16px] font-black uppercase tracking-tight text-paper">
            ScrollFrame
          </div>
          <div className="font-mono text-[9.5px] font-bold tracking-[0.28em] text-paper/50 uppercase">
            Studio
          </div>
        </div>
      </div>

      {/* nav */}
      <nav className="mt-4 space-y-2 px-3">
        {items.map((it) => {
          const active = view === it.id;
          return (
            <button
              key={it.id}
              onClick={() => setView(it.id)}
              className={`flex w-full items-center gap-3 px-3 py-2.5 text-left text-[13px] font-bold uppercase tracking-wide transition-all ${
                active
                  ? "bg-accent text-ink shadow-[3px_3px_0_0_#faf7ef]"
                  : "text-paper/60 hover:bg-paper/10 hover:text-paper"
              }`}
            >
              <span className="font-mono text-[10px] font-black opacity-70">{it.num}</span>
              {it.icon}
              <span>{it.label}</span>
            </button>
          );
        })}
        <button
          onClick={() => setSettingsOpen(true)}
          className="flex w-full items-center gap-3 px-3 py-2.5 text-left text-[13px] font-bold uppercase tracking-wide text-paper/60 transition-all hover:bg-paper/10 hover:text-paper"
        >
          <span className="font-mono text-[10px] font-black opacity-70">03</span>
          <Settings className={ICON_CLS} />
          <span>Settings</span>
        </button>
      </nav>

      {/* recent projects */}
      <div className="mt-6 flex min-h-0 flex-1 flex-col px-3">
        <div className="mb-2 px-1 font-mono text-[9.5px] font-bold tracking-[0.24em] text-paper/40 uppercase">
          // Recent projects
        </div>
        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto pb-2">
          {projects.length === 0 && (
            <div className="px-1 py-3 text-xs leading-relaxed text-paper/35">
              No projects yet. Upload a video to create your first scroll experience.
            </div>
          )}
          {projects.slice(0, 8).map((p) => {
            const active = p.id === activeProjectId;
            return (
              <button
                key={p.id}
                onClick={() => selectProject(p.id)}
                className={`flex w-full items-center gap-2.5 border-2 px-2 py-2 text-left transition-all ${
                  active
                    ? "border-accent bg-accent/15"
                    : "border-paper/20 bg-paper/5 hover:border-paper/50"
                }`}
              >
                <div className="grid h-8 w-8 shrink-0 place-items-center bg-paper">
                  {p.result.mode === "video" ? (
                    <Film className="h-4 w-4 text-ink" />
                  ) : (
                    <Layers className="h-4 w-4 text-ink" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] font-bold text-paper">{p.name}</div>
                  <div className="font-mono text-[10px] text-paper/45">
                    {p.result.count}fr · {formatBytes(projectSize(p))}
                  </div>
                </div>
                <Video className="h-3.5 w-3.5 shrink-0 text-paper/40" />
              </button>
            );
          })}
        </div>
      </div>
    </aside>
  );
}
