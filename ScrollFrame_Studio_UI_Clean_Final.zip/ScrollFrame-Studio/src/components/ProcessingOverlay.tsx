import { useEffect, useMemo, useState } from "react";
import { Check, ChevronDown, CircleAlert, Clapperboard, Loader2, Terminal, X } from "lucide-react";
import { useStudioStore } from "../store/useStudioStore";
import { STAGES, STAGE_INDEX } from "../types";

export default function ProcessingOverlay() {
  const processing = useStudioStore((s) => s.processing);
  const cancelProcessing = useStudioStore((s) => s.cancelProcessing);
  const [showLogs, setShowLogs] = useState(false);

  const stageIdx = STAGE_INDEX[processing.stage];
  const stage = processing.stage;

  const etaLabel = useMemo(() => {
    if (processing.etaSeconds == null || !Number.isFinite(processing.etaSeconds)) return null;
    const s = Math.max(0, Math.round(processing.etaSeconds));
    if (s < 60) return `~${s}s remaining`;
    return `~${Math.floor(s / 60)}m ${s % 60}s remaining`;
  }, [processing.etaSeconds]);

  const elapsed = useMemo(() => {
    const s = Math.round(processing.elapsedMs / 1000);
    return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${s % 60}s`;
  }, [processing.elapsedMs]);

  useEffect(() => {
    if (stage === "complete") {
      const t = setTimeout(() => setShowLogs(false), 400);
      return () => clearTimeout(t);
    }
  }, [stage]);

  const isDone = stage === "complete";
  const isError = stage === "error";

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-paper/80">
      <div className="sf-pop w-full max-w-lg sf-card sf-topbar bg-card p-7">
        {/* header */}
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 shrink-0 place-items-center border-2 border-ink bg-accent shadow-[3px_3px_0_0_#161616]">
            <Clapperboard className="h-5 w-5 text-ink" />
          </div>
          <div>
            <h2 className="font-display text-[16px] font-black uppercase tracking-wide text-ink">
              {isDone ? "Processing complete" : isError ? "Processing failed" : "Processing video"}
            </h2>
            <p className="font-mono text-[11px] text-ink/55">
              {isDone
                ? "Your scroll website is ready to preview."
                : isError
                  ? "Something went wrong — see details below."
                  : "All work happens locally in your browser."}
            </p>
          </div>
        </div>

        {/* progress */}
        <div className="mt-6">
          <div className="flex items-end justify-between">
            <div className="text-[12.5px] font-black uppercase text-ink">
              {processing.stage === "complete"
                ? "Complete"
                : `${Math.round(processing.percent)}% · ${STAGES[Math.max(0, stageIdx)]?.label ?? "Working…"}`}
            </div>
            <div className="flex gap-3 font-mono text-[10.5px] font-bold text-ink/50">
              {etaLabel && !isDone && <span>{etaLabel}</span>}
              <span>elapsed {elapsed}</span>
            </div>
          </div>
          <div className="mt-2 h-5 border-2 border-ink bg-white">
            <div
              className={`h-full transition-[width] duration-300 ${
                isError ? "bg-danger" : isDone ? "bg-ok" : "bg-accent"
              }`}
              style={{ width: `${isDone ? 100 : Math.max(2, processing.percent)}%` }}
            />
          </div>
        </div>

        {/* stage list */}
        <div className="mt-6 grid grid-cols-1 gap-1.5">
          {STAGES.map((s, i) => {
            const failStage = isError && processing.errorStage === s.id;
            const done = isDone || i < stageIdx;
            const current = !isDone && !isError && i === stageIdx;
            return (
              <div
                key={s.id}
                className={`flex items-center gap-3 border-2 px-3 py-2 ${
                  current ? "border-accent bg-accent/10" : failStage ? "border-danger bg-danger/10" : "border-transparent"
                }`}
              >
                {failStage ? (
                  <CircleAlert className="h-4 w-4 shrink-0 text-danger" />
                ) : done ? (
                  <span className="grid h-5 w-5 shrink-0 place-items-center border-2 border-ink bg-ok text-paper">
                    <Check className="h-3 w-3" />
                  </span>
                ) : current ? (
                  <Loader2 className="h-4 w-4 shrink-0 animate-spin text-accent" />
                ) : (
                  <span className="h-5 w-5 shrink-0 border-2 border-ink/30 bg-white" />
                )}
                <span
                  className={`font-mono text-[12px] font-bold uppercase tracking-wide ${
                    failStage
                      ? "text-danger"
                      : done
                        ? "text-ink/50 line-through decoration-accent decoration-2"
                        : current
                          ? "text-ink"
                          : "text-ink/35"
                  }`}
                >
                  {s.label}
                </span>
                {current && processing.framesTotal > 0 && (s.id === "extracting" || s.id === "optimizing") && (
                  <span className="ml-auto font-mono text-[11px] font-bold tabular-nums text-ink/55">
                    {processing.framesDone.toLocaleString()} / {processing.framesTotal.toLocaleString()} frames
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* frames + logs */}
        <div className="mt-5 flex items-center justify-between">
          <button
            onClick={() => setShowLogs((v) => !v)}
            className="inline-flex items-center gap-1.5 border-2 border-ink/30 px-2 py-1 font-mono text-[10.5px] font-bold uppercase text-ink/60 transition-colors hover:border-ink hover:text-ink"
          >
            <Terminal className="h-3.5 w-3.5" /> Processing log
            <ChevronDown className={`h-3.5 w-3.5 transition-transform ${showLogs ? "rotate-180" : ""}`} />
          </button>
          {processing.framesTotal > 0 && (
            <span className="font-mono text-[11px] font-bold text-ink/50">
              {processing.framesTotal.toLocaleString()} frames total
            </span>
          )}
        </div>
        {showLogs && (
          <div className="mt-2 max-h-44 overflow-y-auto border-2 border-ink bg-white p-3 font-mono text-[11px] leading-relaxed text-ink/70">
            {processing.logs.length === 0 && <span className="text-ink/35">No output yet…</span>}
            {processing.logs.map((l, i) => (
              <div key={i}>{l}</div>
            ))}
          </div>
        )}

        {/* error */}
        {isError && processing.error && (
          <div className="mt-4 flex items-start gap-2.5 border-2 border-danger bg-danger/10 px-4 py-3 text-[12.5px] leading-relaxed text-ink">
            <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-danger" />
            <span>{processing.error}</span>
          </div>
        )}

        {/* actions */}
        <div className="mt-6 flex gap-3">
          {!isDone && !isError && (
            <button
              onClick={cancelProcessing}
              className="sf-btn flex-1 sf-btn-ghost"
            >
              <X className="h-4 w-4" /> Cancel
            </button>
          )}
          {isError && (
            <button
              onClick={() => useStudioStore.getState().clearError()}
              className="sf-btn flex-1"
            >
              Close
            </button>
          )}
          {isDone && (
            <button
              onClick={() => useStudioStore.getState().dismissProcessing()}
              className="sf-btn sf-btn-accent flex-1"
            >
              View project
            </button>
          )}
        </div>

        {isDone && (
          <p className="mt-4 text-center font-mono text-[10.5px] font-bold text-ink/50">
            Now customize the design, preview it live, and export the website as a ZIP.
          </p>
        )}
      </div>
    </div>
  );
}
