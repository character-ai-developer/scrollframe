import { useStudioStore } from "../store/useStudioStore";
import SettingsPane from "./SettingsPane";
import PreviewPane from "./PreviewPane";
import ExportPane from "./ExportPane";

export default function WorkspaceView() {
  const project = useStudioStore((s) => s.projects.find((p) => p.id === s.activeProjectId));

  if (!project) {
    return (
      <div className="grid h-full place-items-center bg-paper">
        <div className="text-center">
          <div className="font-display text-4xl">🎬</div>
          <p className="mt-3 font-mono text-sm text-ink/60">Select a project to open the workspace.</p>
          <button
            onClick={() => useStudioStore.getState().setView("dashboard")}
            className="sf-btn mt-5"
          >
            Go to projects
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full min-h-0 bg-paper">
      {/* left: settings */}
      <div className="hidden w-[300px] shrink-0 border-r-[3px] border-ink bg-paper lg:block xl:w-[330px]">
        <SettingsPane project={project} />
      </div>

      {/* center: live preview */}
      <div className="min-w-0 flex-1 border-r-[3px] border-ink bg-paper">
        <PreviewPane project={project} />
      </div>

      {/* right: export */}
      <div className="hidden w-[290px] shrink-0 md:block xl:w-[320px]">
        <ExportPane project={project} />
      </div>
    </div>
  );
}
