import { ChevronDown, Info, Palette, PlayCircle, SlidersHorizontal, Layers, RefreshCw, Sparkles } from "lucide-react";
import { useState } from "react";
import { useStudioStore } from "../store/useStudioStore";
import type { ProjectRecord, SiteSettings } from "../types";
import { travelVhFor } from "../lib/site/generator";

function Section({
  icon,
  title,
  children,
  defaultOpen = true,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="sf-card-flat">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between border-b-2 border-ink px-4 py-3 text-left"
      >
        <span className="flex items-center gap-2.5 text-[12.5px] font-black uppercase tracking-wide text-ink">
          <span className="text-accent">{icon}</span>
          {title}
        </span>
        <ChevronDown className={`h-4 w-4 text-ink transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <div className="space-y-4 px-4 pb-4 pt-4">{children}</div>}
    </div>
  );
}

function SliderField({
  label,
  value,
  min,
  max,
  step = 1,
  display,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  display: string;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-[12px] font-bold text-ink/80">{label}</span>
        <span className="sf-chip !py-0.5 !px-1.5 text-accent">{display}</span>
      </div>
      <input
        type="range"
        className="sf-range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(+e.target.value)}
      />
    </div>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)} className="flex w-full items-center justify-between py-0.5">
      <span className="text-[12.5px] font-bold text-ink/80">{label}</span>
      <span
        className={`grid h-6 w-6 place-items-center border-2 border-ink font-mono text-[13px] font-black transition-colors ${
          checked ? "bg-accent text-ink" : "bg-white text-ink/30"
        }`}
      >
        {checked ? "✔" : ""}
      </span>
    </button>
  );
}

function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[12.5px] font-bold text-ink/80">{label}</span>
      <div className="flex items-center gap-2">
        <span className="font-mono text-[10.5px] font-bold uppercase text-ink/50">{value}</span>
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-8 w-10" />
      </div>
    </div>
  );
}

export default function SettingsPane({ project }: { project: ProjectRecord }) {
  const updateSiteSettings = useStudioStore((s) => s.updateSiteSettings);
  const setView = useStudioStore((s) => s.setView);
  const s = project.siteSettings;
  const set = (patch: Partial<SiteSettings>) => updateSiteSettings(project.id, patch);

  const travel = travelVhFor(s);

  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 items-center justify-between border-b-[3px] border-ink bg-ink px-4 py-3 text-paper">
        <div className="flex items-center gap-2 text-[13px] font-black uppercase tracking-wide">
          <SlidersHorizontal className="h-4 w-4 text-accent" />
          Customize
        </div>
        <button
          onClick={() => {
            useStudioStore.getState().selectProject(null);
            setView("upload");
          }}
          className="inline-flex items-center gap-1.5 border-2 border-paper/30 px-2 py-1 font-mono text-[10.5px] font-bold uppercase text-paper/80 transition-colors hover:border-accent hover:text-accent"
        >
          <RefreshCw className="h-3 w-3" /> New video
        </button>
      </div>

      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-paper p-4">
        {/* background */}
        <Section icon={<Palette className="h-4 w-4" />} title="Background">
          <div>
            <span className="sf-label">Style</span>
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  ["solid", "Solid"],
                  ["gradient", "Gradient"],
                  ["dark-overlay", "Dark overlay"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  onClick={() => set({ backgroundStyle: id })}
                  className={`border-2 px-2 py-1.5 text-[11.5px] font-black uppercase transition-all ${
                    s.backgroundStyle === id
                      ? "border-ink bg-accent shadow-[2px_2px_0_0_#161616]"
                      : "border-ink/30 bg-white text-ink/60 hover:border-ink"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          {s.backgroundStyle === "solid" && (
            <ColorField label="Background color" value={s.backgroundColor} onChange={(v) => set({ backgroundColor: v })} />
          )}
          {s.backgroundStyle === "gradient" && (
            <>
              <ColorField label="Gradient from" value={s.backgroundGradientFrom} onChange={(v) => set({ backgroundGradientFrom: v })} />
              <ColorField label="Gradient to" value={s.backgroundGradientTo} onChange={(v) => set({ backgroundGradientTo: v })} />
            </>
          )}
          {s.backgroundStyle === "dark-overlay" && (
            <ColorField label="Overlay base color" value={s.backgroundColor} onChange={(v) => set({ backgroundColor: v })} />
          )}
          <ColorField label="Text color" value={s.textColor} onChange={(v) => set({ textColor: v })} />
          <ColorField label="Accent color" value={s.accentColor} onChange={(v) => set({ accentColor: v })} />
          <div>
            <span className="sf-label">Typography</span>
            <select className="sf-input" value={s.fontFamily} onChange={(e) => set({ fontFamily: e.target.value as SiteSettings["fontFamily"] })}>
              <option value="inter">Inter (modern)</option>
              <option value="system">System stack</option>
              <option value="serif">Serif (editorial)</option>
            </select>
          </div>
        </Section>

        {/* animation */}
        <Section icon={<PlayCircle className="h-4 w-4" />} title="Animation">
          <div className="border-2 border-ink/25 bg-white px-3 py-2.5 font-mono text-[11px] leading-relaxed text-ink/70">
            Scroll section: <span className="font-black text-accent">{travel}vh</span> (≈{" "}
            {Math.round(travel / 100)} screens)
          </div>
          <SliderField
            label="Animation duration"
            value={s.animationDuration}
            min={2}
            max={30}
            display={`${s.animationDuration}s`}
            onChange={(v) => set({ animationDuration: v })}
          />
          <SliderField
            label="Scroll sensitivity"
            value={s.scrollSensitivity}
            min={0.5}
            max={2}
            step={0.1}
            display={`${s.scrollSensitivity.toFixed(1)}×`}
            onChange={(v) => set({ scrollSensitivity: v })}
          />
          <SliderField
            label="Smoothing"
            value={s.smoothing}
            min={0}
            max={1}
            step={0.05}
            display={s.smoothing === 0 ? "snappy" : s.smoothing >= 0.8 ? "floaty" : `${Math.round(s.smoothing * 100)}%`}
            onChange={(v) => set({ smoothing: v })}
          />
          <div className="grid grid-cols-2 gap-3">
            <SliderField
              label="Start offset"
              value={s.startOffset}
              min={0}
              max={40}
              display={`${s.startOffset}vh`}
              onChange={(v) => set({ startOffset: v })}
            />
            <SliderField
              label="End offset"
              value={s.endOffset}
              min={0}
              max={40}
              display={`${s.endOffset}vh`}
              onChange={(v) => set({ endOffset: v })}
            />
          </div>
          <div>
            <span className="sf-label">Easing</span>
            <select className="sf-input" value={s.easing} onChange={(e) => set({ easing: e.target.value as SiteSettings["easing"] })}>
              <option value="smoothstep">Smoothstep (cinematic)</option>
              <option value="ease-in-out">Ease in / out</option>
              <option value="linear">Linear</option>
            </select>
          </div>
          <div>
            <span className="sf-label">Canvas fit</span>
            <div className="grid grid-cols-2 gap-1.5">
              {(
                [
                  ["cover", "Cover (fill & crop)"],
                  ["contain", "Contain (letterbox)"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  onClick={() => set({ fitMode: id })}
                  className={`border-2 px-2 py-1.5 text-[11.5px] font-black uppercase transition-all ${
                    s.fitMode === id
                      ? "border-ink bg-accent shadow-[2px_2px_0_0_#161616]"
                      : "border-ink/30 bg-white text-ink/60 hover:border-ink"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <Toggle
            label="Reverse when scrolling up"
            checked={s.reverseOnScrollUp}
            onChange={(v) => set({ reverseOnScrollUp: v })}
          />
        </Section>

        {/* optional UI */}
        <Section icon={<Layers className="h-4 w-4" />} title="Optional UI" defaultOpen={false}>
          <Toggle label="Loading screen" checked={s.showLoadingScreen} onChange={(v) => set({ showLoadingScreen: v })} />
          <Toggle label="Scroll indicator" checked={s.showScrollIndicator} onChange={(v) => set({ showScrollIndicator: v })} />
          <Toggle label="Progress bar" checked={s.showProgress} onChange={(v) => set({ showProgress: v })} />
          <Toggle label="Play / pause button" checked={s.showPlayPause} onChange={(v) => set({ showPlayPause: v })} />
          <Toggle label="Fullscreen button" checked={s.showFullscreen} onChange={(v) => set({ showFullscreen: v })} />
          <Toggle label="Sound button" checked={s.showSound} onChange={(v) => set({ showSound: v })} />
          <div>
            <span className="sf-label">Intro text (shown before the animation)</span>
            <input
              className="sf-input"
              value={s.introText}
              placeholder="e.g. A journey through the clouds"
              onChange={(e) => set({ introText: e.target.value })}
            />
          </div>
          <div>
            <span className="sf-label">Outro text (shown after)</span>
            <input
              className="sf-input"
              value={s.outroText}
              placeholder="Optional closing message…"
              onChange={(e) => set({ outroText: e.target.value })}
            />
          </div>
        </Section>

        {/* mode info */}
        <div className="flex items-start gap-2.5 border-2 border-ink bg-white px-4 py-3">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
          <div className="text-[11.5px] leading-relaxed text-ink/70">
            <span className="font-black uppercase">
              {project.result.mode === "frames" ? "Frame Mode" : "Video Mode"}
            </span>{" "}
            — {project.result.count} frames at {project.result.fps} FPS, {project.result.width}×
            {project.result.height}px. Changing extraction settings requires re-processing the video.
          </div>
        </div>
        <div className="flex items-center gap-2 px-1 pb-2 font-mono text-[10.5px] font-bold text-ink/50">
          <Sparkles className="h-3.5 w-3.5 text-accent" />
          Every change updates the live preview instantly.
        </div>
      </div>
    </div>
  );
}
