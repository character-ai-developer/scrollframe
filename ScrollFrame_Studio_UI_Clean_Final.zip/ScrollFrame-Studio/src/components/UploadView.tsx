import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertCircle,
  ArrowLeft,
  Check,
  Cpu,
  FileVideo2,
  Gauge,
  Image as ImageIcon,
  Layers,
  Play,
  Sparkles,
  UploadCloud,
  Wand2,
  Film,
} from "lucide-react";
import { useStudioStore } from "../store/useStudioStore";
import type { GenerationMode, ImageFormat, PresetId, ProcessingSettings, VideoMeta } from "../types";
import {
  DEFAULT_PROCESSING,
  MAX_FILE_SIZE_MB,
  PRESET_DEFS,
  formatBytes,
  formatDuration,
} from "../types";
import { probeVideoMeta, validateVideoFile, VideoValidationError, aspectRatioLabel } from "../utils/video";

const SECTION = "sf-card-flat p-5";
const LABEL = "sf-label";
const INPUT = "sf-input";

export default function UploadView() {
  const setView = useStudioStore((s) => s.setView);
  const processVideoFile = useStudioStore((s) => s.processVideoFile);
  const maxFileSizeMB = useStudioStore((s) => s.maxFileSizeMB);

  const [file, setFile] = useState<File | null>(null);
  const [meta, setMeta] = useState<VideoMeta | null>(null);
  const [metaError, setMetaError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [settings, setSettings] = useState<ProcessingSettings>({ ...DEFAULT_PROCESSING });
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const probingRef = useRef(0);

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  const applyPreset = (id: PresetId) => {
    const p = PRESET_DEFS.find((x) => x.id === id)!;
    setSettings((s) => ({
      ...s,
      preset: id,
      fps: p.fps,
      imageQuality: p.quality,
      maxResolution: p.maxResolution,
      maxFrames: p.maxFrames,
    }));
  };

  const handleFile = useCallback(
    (f: File) => {
      try {
        validateVideoFile(f, maxFileSizeMB * 1024 * 1024);
      } catch (err) {
        setMetaError(err instanceof Error ? err.message : String(err));
        setFile(null);
        setMeta(null);
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        setPreviewUrl(null);
        return;
      }
      setMetaError(null);
      setFile(f);
      setPreviewUrl((old) => {
        if (old) URL.revokeObjectURL(old);
        return URL.createObjectURL(f);
      });
      const myProbe = ++probingRef.current;
      probeVideoMeta(f)
        .then((m) => {
          if (probingRef.current === myProbe) setMeta(m);
        })
        .catch((err) => {
          if (probingRef.current === myProbe) {
            setMetaError(err instanceof Error ? err.message : String(err));
            setMeta(null);
          }
        });
    },
    [maxFileSizeMB, previewUrl],
  );

  const stats = useMemo(() => {
    if (!meta) return null;
    const fps = settings.fps;
    const frames = Math.max(1, Math.round(meta.duration * fps));
    const capped = settings.maxFrames > 0 ? Math.min(frames, settings.maxFrames) : frames;
    const effFps = capped / meta.duration;
    return { frames, capped, effFps };
  }, [meta, settings.fps, settings.maxFrames]);

  const canProcess = file !== null && meta !== null && !metaError;

  return (
    <div className="h-full overflow-y-auto bg-paper">
      <div className="mx-auto max-w-6xl px-6 py-8 md:px-10">
        {/* header */}
        <div className="mb-7 flex items-center justify-between border-b-[3px] border-ink pb-5">
          <div>
            <div className="flex items-center gap-2 font-mono text-[11px] font-black tracking-[0.2em] text-ink/60 uppercase">
              <span className="bg-accent px-1.5 py-0.5 text-ink">01</span> Upload video
            </div>
            <h1 className="mt-2 font-display text-3xl font-black uppercase tracking-tight">New project</h1>
          </div>
          <button onClick={() => setView("dashboard")} className="sf-btn sf-btn-sm sf-btn-ghost">
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr]">
          {/* ------------------------------------------------ left column */}
          <div className="space-y-6">
            {/* dropzone */}
            <div className={SECTION}>
              <label className={LABEL}>Video source</label>
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(false);
                  const f = e.dataTransfer.files?.[0];
                  if (f) handleFile(f);
                }}
                onClick={() => inputRef.current?.click()}
                className={`relative cursor-pointer border-[3px] border-dashed p-8 text-center transition-all ${
                  dragOver ? "border-ink bg-accent/15" : "border-ink/50 bg-white hover:border-ink hover:bg-accent/5"
                }`}
              >
                <input
                  ref={inputRef}
                  type="file"
                  accept="video/*,.mp4,.webm,.mov,.m4v,.ogv,.avi,.mkv"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleFile(f);
                    e.target.value = "";
                  }}
                />
                {!file ? (
                  <div className="py-4">
                    <div className="mx-auto grid h-14 w-14 place-items-center border-2 border-ink bg-accent shadow-[4px_4px_0_0_#161616]">
                      <UploadCloud className="h-7 w-7 text-ink" />
                    </div>
                    <div className="mt-4 text-[15px] font-black uppercase tracking-wide">
                      Drag &amp; drop your video
                    </div>
                    <div className="mt-1.5 text-[13px] text-ink/60">
                      or <span className="font-black text-ink underline decoration-accent decoration-2 underline-offset-2">browse files</span> — MP4,
                      WebM, MOV, M4V, OGV, AVI, MKV
                    </div>
                    <div className="sf-chip mt-4 bg-paper">
                      <Cpu className="h-3 w-3 text-ok" />
                      Max {maxFileSizeMB} MB · processed locally in your browser
                    </div>
                  </div>
                ) : (
                  <div className="py-2 text-left">
                    <div className="flex items-center gap-4">
                      <div className="relative h-24 w-36 shrink-0 overflow-hidden border-2 border-ink bg-ink">
                        {previewUrl && (
                          <video
                            src={previewUrl}
                            muted
                            loop
                            playsInline
                            className="h-full w-full object-contain"
                          />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <FileVideo2 className="h-4 w-4 shrink-0 text-accent" />
                          <span className="truncate text-[14px] font-black text-ink">{file.name}</span>
                        </div>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          <Chip label={formatBytes(file.size)} />
                          {meta && (
                            <>
                              <Chip label={formatDuration(meta.duration)} />
                              <Chip label={`${meta.width}×${meta.height}`} />
                              <Chip label={`${meta.fps} fps`} />
                              <Chip label={aspectRatioLabel(meta.width, meta.height)} />
                            </>
                          )}
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setFile(null);
                            setMeta(null);
                            setMetaError(null);
                          }}
                          className="mt-3 font-mono text-[11.5px] font-bold text-ink/55 underline decoration-accent decoration-2 underline-offset-2 hover:text-ink"
                        >
                          [x] Remove and choose another
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {metaError && (
                <div className="mt-3 flex items-start gap-2.5 border-2 border-danger bg-danger/10 px-4 py-3 text-[13px] leading-relaxed text-ink">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-danger" />
                  <span>{metaError}</span>
                </div>
              )}

              {meta && stats && (
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <Stat label="Duration" value={formatDuration(meta.duration)} />
                  <Stat label="Resolution" value={`${meta.width}×${meta.height}`} />
                  <Stat label="Frame rate" value={`${meta.fps.toFixed(1)} fps`} />
                  <Stat label="Aspect" value={aspectRatioLabel(meta.width, meta.height)} />
                </div>
              )}
            </div>

            {/* video preview */}
            {previewUrl && (
              <div className={SECTION}>
                <div className="mb-2 flex items-center gap-2">
                  <Play className="h-3.5 w-3.5 text-accent" />
                  <span className="sf-label !mb-0">Source preview</span>
                </div>
                <video
                  src={previewUrl}
                  controls
                  muted
                  playsInline
                  className="max-h-72 w-full border-2 border-ink bg-ink"
                />
              </div>
            )}
          </div>

          {/* ----------------------------------------------- right column */}
          <div className="space-y-6">
            {/* presets */}
            <div className={SECTION}>
              <div className="mb-3 flex items-center gap-2">
                <Wand2 className="h-3.5 w-3.5 text-accent" />
                <span className="sf-label !mb-0">Quality preset</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {PRESET_DEFS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => applyPreset(p.id)}
                    className={`border-2 px-3 py-3 text-left transition-all ${
                      settings.preset === p.id
                        ? "border-ink bg-accent shadow-[3px_3px_0_0_#161616]"
                        : "border-ink/30 bg-white hover:border-ink hover:shadow-[2px_2px_0_0_#161616]"
                    }`}
                  >
                    <div className="text-[12.5px] font-black uppercase tracking-wide">{p.name}</div>
                    <div className="mt-0.5 text-[10.5px] leading-snug text-ink/60">{p.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* extraction settings */}
            <div className={SECTION}>
              <div className="mb-3 flex items-center gap-2">
                <Gauge className="h-3.5 w-3.5 text-accent" />
                <span className="sf-label !mb-0">Frame extraction</span>
              </div>
              <div className="space-y-4">
                <Field label={`Target FPS — ${settings.fps}`}>
                  <input
                    type="range"
                    min={1}
                    max={60}
                    value={settings.fps}
                    onChange={(e) => setSettings((s) => ({ ...s, fps: +e.target.value, preset: "balanced" }))}
                    className="sf-range"
                  />
                  <div className="mt-1 flex justify-between font-mono text-[10px] font-bold text-ink/50">
                    <span>1</span>
                    <span>60</span>
                  </div>
                </Field>
                <Field label={`Maximum frames — ${settings.maxFrames}`}>
                  <input
                    type="range"
                    min={60}
                    max={1800}
                    step={10}
                    value={settings.maxFrames}
                    onChange={(e) =>
                      setSettings((s) => ({ ...s, maxFrames: +e.target.value, preset: "balanced" }))
                    }
                    className="sf-range"
                  />
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Image format">
                    <select
                      className={INPUT}
                      value={settings.imageFormat}
                      onChange={(e) =>
                        setSettings((s) => ({ ...s, imageFormat: e.target.value as ImageFormat }))
                      }
                    >
                      <option value="webp">WebP (recommended)</option>
                      <option value="jpeg">JPEG</option>
                      <option value="png">PNG</option>
                    </select>
                  </Field>
                  <Field label={`Quality — ${settings.imageQuality}`}>
                    <input
                      type="range"
                      min={30}
                      max={100}
                      value={settings.imageQuality}
                      onChange={(e) =>
                        setSettings((s) => ({ ...s, imageQuality: +e.target.value, preset: "balanced" }))
                      }
                      className="sf-range mt-3"
                    />
                  </Field>
                </div>
                <Field label={`Maximum resolution (longest edge) — ${settings.maxResolution}px`}>
                  <select
                    className={INPUT}
                    value={settings.maxResolution}
                    onChange={(e) =>
                      setSettings((s) => ({ ...s, maxResolution: +e.target.value, preset: "balanced" }))
                    }
                  >
                    <option value={640}>640px — tiny</option>
                    <option value={960}>960px — small</option>
                    <option value={1280}>1280px — HD</option>
                    <option value={1600}>1600px — high</option>
                    <option value={1920}>1920px — full HD</option>
                    <option value={2560}>2560px — 2K</option>
                  </select>
                </Field>
              </div>
            </div>

            {/* mode */}
            <div className={SECTION}>
              <div className="mb-3 flex items-center gap-2">
                <Layers className="h-3.5 w-3.5 text-accent" />
                <span className="sf-label !mb-0">Generation mode</span>
              </div>
              <ModePicker
                value={settings.mode}
                onChange={(m) => setSettings((s) => ({ ...s, mode: m }))}
              />
              <div className="mt-3 border-2 border-ink/25 bg-white px-3 py-2.5 text-[11.5px] leading-relaxed text-ink/65">
                <span className="font-black text-ink">Frame Mode</span> extracts optimized frames for
                frame-perfect scrubbing. <span className="font-black text-ink">Video Mode</span> embeds
                the video and maps scroll → <code className="bg-accent/30 px-1 font-mono text-[10.5px]">currentTime</code>.
                The studio recommends the best mode after analyzing your file.
              </div>
            </div>

            {/* CTA */}
            <button
              disabled={!canProcess}
              onClick={() => {
                if (!file) return;
                void processVideoFile(file, settings).then((p) => {
                  if (!p) return;
                  setFile(null);
                  setMeta(null);
                  setMetaError(null);
                  setSettings({ ...DEFAULT_PROCESSING });
                });
              }}
              className="sf-btn sf-btn-accent w-full px-6 py-4 text-[14px]"
            >
              <Sparkles className="h-5 w-5" />
              {canProcess
                ? `Process video${stats ? ` — ${stats.capped} frames` : ""}`
                : file
                  ? "Reading video metadata…"
                  : "Upload a video to continue"}
            </button>

            {stats && meta && (
              <div className="flex flex-wrap items-center justify-center gap-4 font-mono text-[10.5px] font-bold text-ink/55">
                <span className="flex items-center gap-1">
                  <Film className="h-3 w-3 text-accent" /> ≈{stats.frames} frames at {settings.fps} fps
                </span>
                <span className="flex items-center gap-1">
                  <ImageIcon className="h-3 w-3 text-accent" /> {formatBytes(meta.fileSize)} source
                </span>
                <span className="flex items-center gap-1">
                  <Check className="h-3 w-3 text-ok" /> {MAX_FILE_SIZE_MB / 1024} GB cap
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------- helpers */

function Chip({ label }: { label: string }) {
  return <span className="sf-chip">{label}</span>;
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-2 border-ink bg-white px-3 py-2.5 shadow-[2px_2px_0_0_#161616]">
      <div className="font-mono text-[9.5px] font-bold tracking-[0.12em] text-ink/50 uppercase">{label}</div>
      <div className="mt-0.5 text-[13px] font-black text-ink">{value}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-[11.5px] font-bold text-ink/75">{label}</div>
      {children}
    </div>
  );
}

function ModePicker({
  value,
  onChange,
}: {
  value: GenerationMode;
  onChange: (m: GenerationMode) => void;
}) {
  const options: { id: GenerationMode; title: string; desc: string }[] = [
    { id: "frames", title: "Frame Mode", desc: "Canvas · frame-perfect scrub" },
    { id: "video", title: "Video Mode", desc: "Native video · lowest memory" },
  ];
  return (
    <div className="grid grid-cols-2 gap-2">
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          className={`border-2 px-3 py-3 text-left transition-all ${
            value === o.id
              ? "border-ink bg-accent shadow-[3px_3px_0_0_#161616]"
              : "border-ink/30 bg-white hover:border-ink"
          }`}
        >
          <div className="text-[13px] font-black uppercase tracking-wide">{o.title}</div>
          <div className="mt-0.5 text-[10.5px] text-ink/60">{o.desc}</div>
        </button>
      ))}
    </div>
  );
}
