import { useEffect, useRef, useState } from "react";
import { Maximize2, Monitor, MousePointerClick, Phone, X } from "lucide-react";
import { useStudioStore } from "../store/useStudioStore";
import type { ProjectRecord } from "../types";
import { buildPreviewUrl } from "../lib/preview";

type Device = "desktop" | "mobile" | "fullscreen";

export default function PreviewPane({ project }: { project: ProjectRecord }) {
  const [device, setDevice] = useState<Device>("desktop");
  const [url, setUrl] = useState<string | null>(null);
  const [key, setKey] = useState(0);
  const revokeRef = useRef<(() => void) | null>(null);
  const [scrollHintVisible, setScrollHintVisible] = useState(true);

  const settings = project.siteSettings;

  // regenerate the preview whenever settings change (debounced)
  useEffect(() => {
    const t = setTimeout(() => {
      revokeRef.current?.();
      const handle = buildPreviewUrl(project);
      revokeRef.current = handle.revoke;
      setUrl(handle.url);
      setKey((k) => k + 1);
      setScrollHintVisible(true);
    }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    settings.backgroundColor,
    settings.backgroundGradientFrom,
    settings.backgroundGradientTo,
    settings.backgroundStyle,
    settings.textColor,
    settings.accentColor,
    settings.fontFamily,
    settings.animationDuration,
    settings.scrollSensitivity,
    settings.startOffset,
    settings.endOffset,
    settings.easing,
    settings.smoothing,
    settings.reverseOnScrollUp,
    settings.fitMode,
    settings.showLoadingScreen,
    settings.showScrollIndicator,
    settings.showProgress,
    settings.showPlayPause,
    settings.showFullscreen,
    settings.showSound,
    settings.introText,
    settings.outroText,
    project.id,
  ]);

  useEffect(() => {
    return () => {
      revokeRef.current?.();
    };
  }, []);

  // auto-hide the scroll hint after a few seconds
  useEffect(() => {
    if (!scrollHintVisible) return;
    const t = setTimeout(() => setScrollHintVisible(false), 7000);
    return () => clearTimeout(t);
  }, [scrollHintVisible, key]);

  const frameCls =
    device === "mobile"
      ? "mx-auto h-full w-[380px] border-[8px] border-ink bg-ink shadow-[6px_6px_0_0_#161616]"
      : device === "desktop"
        ? "h-full w-full"
        : "h-full w-full";

  return (
    <div className="flex h-full min-h-0 flex-col bg-paper">
      {/* toolbar */}
      <div className="flex shrink-0 items-center justify-between border-b-[3px] border-ink px-3 py-2">
        <div className="flex items-center gap-1 bg-white p-1 shadow-[2px_2px_0_0_#161616]">
          <DeviceBtn active={device === "desktop"} onClick={() => setDevice("desktop")} title="Desktop preview">
            <Monitor className="h-3.5 w-3.5" />
          </DeviceBtn>
          <DeviceBtn active={device === "mobile"} onClick={() => setDevice("mobile")} title="Mobile preview">
            <Phone className="h-3.5 w-3.5" />
          </DeviceBtn>
          <DeviceBtn active={device === "fullscreen"} onClick={() => setDevice("fullscreen")} title="Fullscreen preview">
            <Maximize2 className="h-3.5 w-3.5" />
          </DeviceBtn>
        </div>
        <div className="flex items-center gap-2">
          <span className="sf-chip !py-0.5 bg-accent">
            <span className="sf-blink text-ink">●</span> LIVE
          </span>
          <span className="hidden items-center gap-1 font-mono text-[10px] font-bold text-ink/50 sm:flex">
            <MousePointerClick className="h-3 w-3" /> scroll to scrub
          </span>
        </div>
      </div>

      {/* viewport */}
      <div className="relative min-h-0 flex-1 overflow-hidden bg-paper">
        <div
          className={`flex h-full items-stretch justify-center transition-all ${
            device === "desktop" ? "p-0" : device === "mobile" ? "bg-ink/10 p-4" : ""
          }`}
        >
          {url && (
            <iframe
              key={key}
              src={url}
              title="Live preview of the generated scroll website"
              sandbox="allow-scripts allow-same-origin allow-pointer-lock"
              className={`${frameCls} border-0 bg-ink`}
              loading="eager"
            />
          )}
        </div>

        {/* scroll hint */}
        {scrollHintVisible && device !== "fullscreen" && (
          <div
            className={`pointer-events-none absolute left-1/2 top-3 z-10 -translate-x-1/2 border-2 border-ink bg-paper px-4 py-2 font-mono text-[11px] font-black uppercase tracking-wide shadow-[3px_3px_0_0_#161616] transition-opacity duration-500 ${
              scrollHintVisible ? "opacity-100" : "opacity-0"
            }`}
          >
            <span className="inline-flex items-center gap-2">
              <MousePointerClick className="h-3.5 w-3.5 text-accent" />
              Scroll to scrub — both directions
            </span>
          </div>
        )}

        {device === "fullscreen" && (
          <button
            onClick={() => setDevice("desktop")}
            className="sf-btn sf-btn-square absolute right-3 top-3 z-10"
            title="Exit fullscreen preview"
          >
            <X className="h-4 w-4" />
          </button>
        )}

        {!url && (
          <div className="absolute inset-0 grid place-items-center font-mono text-sm font-bold text-ink/50">
            Building preview…
          </div>
        )}
      </div>
    </div>
  );
}

function DeviceBtn({
  active,
  onClick,
  title,
  children,
}: {
  active: boolean;
  onClick: () => void;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`grid h-8 w-9 place-items-center border-2 transition-all ${
        active ? "border-ink bg-accent text-ink" : "border-transparent text-ink/50 hover:text-ink"
      }`}
    >
      {children}
    </button>
  );
}
